#!/bin/bash
mkdir data
wget http://yuilibrary.com/yui/docs/guides/ -O data/official.html
wget http://yuilibrary.com/gallery/show/ -O data/gallery.html
