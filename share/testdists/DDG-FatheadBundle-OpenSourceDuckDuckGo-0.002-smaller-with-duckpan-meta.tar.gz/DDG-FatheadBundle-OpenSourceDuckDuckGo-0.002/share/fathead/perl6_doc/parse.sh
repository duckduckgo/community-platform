perl parse.pl > output.txt
