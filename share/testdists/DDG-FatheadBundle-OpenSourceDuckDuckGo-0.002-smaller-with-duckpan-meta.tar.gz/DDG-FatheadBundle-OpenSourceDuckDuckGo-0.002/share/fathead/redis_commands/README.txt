Dependencies

# Freebsd
cd /usr/ports/devel/py-lxml && make && make install

# Ubuntu
sudo apt-get -y install python-lxml

