#!/bin/bash
mkdir -p download
wget "http://redis.io/commands" -O download/raw.dat
