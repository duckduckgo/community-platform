#!/bin/bash

mkdir -p download
cd download
wget http://html5doctor.com/element-index/
cd ../
