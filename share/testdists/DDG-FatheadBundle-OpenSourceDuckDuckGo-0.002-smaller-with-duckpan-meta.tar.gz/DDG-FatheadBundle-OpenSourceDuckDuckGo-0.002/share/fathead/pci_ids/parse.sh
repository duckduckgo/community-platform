#!/bin/bash

perl parse.pl
