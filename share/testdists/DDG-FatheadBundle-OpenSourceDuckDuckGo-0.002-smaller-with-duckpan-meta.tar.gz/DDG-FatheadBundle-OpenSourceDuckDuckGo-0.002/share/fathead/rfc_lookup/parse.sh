#!/bin/bash
perl parse.pl < download/rfc-index.xml > output.txt
