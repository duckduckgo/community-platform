# Probably best to go to the below and accept otherwise this probably will not work
# http://www.oracle.com/technetwork/java/javase/downloads/jdk-6u25-doc-download-355137.html
wget http://download.oracle.com/otn-pub/java/jdk/6u30-b12/jdk-6u30-apidocs.zip
