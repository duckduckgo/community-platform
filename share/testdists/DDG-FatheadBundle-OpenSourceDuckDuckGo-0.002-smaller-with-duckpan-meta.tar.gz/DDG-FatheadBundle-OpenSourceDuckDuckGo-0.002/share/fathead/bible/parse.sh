#!/bin/bash

cd $(dirname -- "$0")

./parse.py
