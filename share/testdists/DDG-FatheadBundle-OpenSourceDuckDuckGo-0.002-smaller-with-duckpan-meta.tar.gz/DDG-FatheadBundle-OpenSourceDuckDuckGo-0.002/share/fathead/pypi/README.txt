sudo apt-get -y install ruby1.9.1 rubygems1.9.1
sudo gem install rubygems-update
sudo apt-get -y install libhpricot-ruby1.9.1
