DuckDuckGo zeroclickinfo-fathead/hgnc_gene_names


----------------------------------------
Required Tools (must be in path)
----------------------------------------
wget
gzip
perl (tested with 5.12)


----------------------------------------
Required Perl Modules
----------------------------------------
IO::Uncompress::AnyInflate
