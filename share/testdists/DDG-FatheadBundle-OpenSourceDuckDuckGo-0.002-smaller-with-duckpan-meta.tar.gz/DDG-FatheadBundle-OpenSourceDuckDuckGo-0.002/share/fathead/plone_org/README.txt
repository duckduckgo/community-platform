# Run the following command to generate the fetch.  This is use because of the variable number of results per category.

ruby generate_fetch.rb > fetch.sh

Appear to be duplicates returned at times (Maybe need to post-process with SELECT DISTINCT...).  

Only 600 rows returned - site claims 1696 releases...hmmm
