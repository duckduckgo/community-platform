Dependencies:

Python 3

To install in Ubuntu 10.04 (Lucid):

sudo apt-get install python3-minimal
