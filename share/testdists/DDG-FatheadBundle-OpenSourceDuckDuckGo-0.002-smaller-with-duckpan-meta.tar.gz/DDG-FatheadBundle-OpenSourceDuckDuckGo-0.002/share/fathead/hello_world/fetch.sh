#!/bin/bash

cd $(dirname -- "$0")

git clone git://github.com/leachim6/hello-world.git download

