Dependencies
------------

Golang

# ubuntu
http://google-go-lang.blogspot.com/2009/11/how-to-install-go-golang-compiler-on.html
