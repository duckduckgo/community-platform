#!/bin/bash
mkdir -p download
wget "http://en.wikipedia.org/wiki/List_of_circulating_currencies" -O download/page.dat
