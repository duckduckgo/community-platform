#!/bin/bash

# Make currency.txt:
python parse.py

