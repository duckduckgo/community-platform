package DDG::Goodie::EmToPx;
{
  $DDG::Goodie::EmToPx::VERSION = '0.088';
}

use DDG::Goodie;

triggers any => "em", "px";

zci is_cached => 1;
zci answer_type => "conversion";

primary_example_queries '10 px to em';
secondary_example_queries '12.2 px in em assuming a 12.2 font size';
description 'convert from px to em';
name 'EmToPx';
code_url 'https://github.com/duckduckgo/zeroclickinfo-goodies/blob/master/lib/DDG/Goodie/EmToPx.pm';
category 'conversions';
topics 'programming';
attribution twitter => 'crazedpsyc',
            cpan    => 'CRZEDPSYC' ;

handle query_raw => sub {
    s/(?![\.\s])\W//g;
    return unless /^(?:convert|change|what\s*(?:s|is|are)\s+)?(\d+\.\d*|\d*\.\d+|\d+)\s*(em|px)\s+(?:in|to)\s+(em|px)(?:\s+(?:with|at|using|assuming)(?:\s+an?)?\s+(\d+\.\d*|\d*\.\d+|\d+)\s*px)?/i;
    my $target = lc($3);
    my $num = $1;
    my $source = lc($2);

    my $fontsize = ( defined $4 ) ? $4 : 16;

    my $result;
    $result = $num * $fontsize if $target eq 'px' && $source eq 'em';
    $result = $num / $fontsize if $target eq 'em' && $source eq 'px';
    my $plur = $result == 1 ? "is" : "are";

    return "There $plur $result $target in $num $source (assuming a ${fontsize}px font size)";
    return;
};

1;

__END__

=pod

=head1 NAME

DDG::Goodie::EmToPx

=head1 VERSION

version 0.088

=head1 AUTHORS

=over 4

=item *

Gabriel Weinberg <yegg@duckduckgo.com>

=item *

Torsten Raudssus <getty@duckduckgo.com>

=item *

Michael Smith <crazedpsyc@duckduckgo.com>

=item *

Hunter Lang <hunter@duckduckgo.com>

=back

=head1 COPYRIGHT AND LICENSE

This software is copyright (c) 2011 by DuckDuckGo, Inc. L<http://duckduckgo.com/>.

This is free software; you can redistribute it and/or modify it under
the same terms as the Perl 5 programming language system itself.

=cut
