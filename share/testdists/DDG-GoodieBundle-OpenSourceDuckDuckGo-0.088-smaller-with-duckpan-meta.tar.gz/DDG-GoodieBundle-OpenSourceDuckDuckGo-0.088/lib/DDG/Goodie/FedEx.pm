package DDG::Goodie::FedEx;
{
  $DDG::Goodie::FedEx::VERSION = '0.088';
}

use DDG::Goodie;

zci is_cached => 1;
zci answer_type => "fedex";

primary_example_queries "fedex 9241990100130206401644";
secondary_example_queries "federal express 9241990100130206401644";

description "Track a FedEx package";
name "FedEx";
icon_url "/i/fedex.com.ico";
source "FedEx";
code_url "https://github.com/duckduckgo/zeroclickinfo-goodies/blob/master/lib/DDG/Goodie/FedEx.pm";
category 'ids';
topics 'special_interest';
attribution web => [ 'https://www.duckduckgo.com', 'DuckDuckGo' ],
            github => [ 'https://github.com/duckduckgo', 'duckduckgo'],
            twitter => ['http://twitter.com/duckduckgo', 'duckduckgo'];

# Regex for fedex.
my $fedex_qr = qr/fed(?:eral|)ex(?:press|)/io;
my $tracking_qr = qr/package|track(?:ing|)|num(?:ber|)|\#/i;

triggers query_nowhitespace_nodash => qr/
                                        ^$fedex_qr.*?([\d]{9,})$|
                                        ^([\d]{9,}).*?$fedex_qr$|
                                        ^(?:$tracking_qr|$fedex_qr|)*?(\d*?)([\d]{15,20})(?:$tracking_qr|$fedex_qr|)*$|
                                        ^(?:$tracking_qr|$fedex_qr|)*?(\d*?)([\d]{12})(?:$tracking_qr|$fedex_qr|)*$
                                        /xio;

# Fedex package tracking.
# See http://answers.google.com/answers/main?cmd=threadview&id=207899
# See http://images.fedex.com/us/solutions/ppe/FedEx_Ground_Label_Layout_Specification.pdf
handle query_nowhitespace_nodash => sub {
    # If a Fedex package number (2 for exclusively).
    my $is_fedex = 0;

    # Tracking number.
    my $package_number = '';

    # Exclsuive trigger.
    if ($1 || $2) {
        $package_number = $1 || $2;
        $is_fedex       = 2;

        # No exclusive trigger, do checksum.
        # Since the package numbers are just numbers,
        # we are more strict in regex (e.g. than UPS).
        # 15 has to be before 12 or it will block.
    }
    elsif (($3 && $4) || ($5 && $6)) {
        my $package_beg = $3 || $5;
        $package_number = $4 || $6;

        my $checksum   = -1;
        my @chars      = split( //, $package_number );
        my $length     = scalar(@chars);
        my $char_count = 0;
        my $sum        = 0;

        # Ground.
        if ( $length == 15 ) {

            my $odd_sum  = 0;
            my $even_sum = 0;
            foreach my $char ( reverse @chars ) {
                $char_count++;

                # Skip check digit.
                next if $char_count == 1;

                if ( $char_count % 2 == 0 ) {
                    $even_sum += $char;
                }
                else {
                    $odd_sum += $char;
                }
            }
            $even_sum *= 3;
            if ( ( $odd_sum + $even_sum ) > 0 ) {
                $checksum = ( $odd_sum + $even_sum ) % 10;
                $checksum = 10 - $checksum if $checksum;
            }
        }
        else {
            foreach my $char (@chars) {

                if ( $char_count % 3 == 0 ) {
                    $sum += $char * 3;
                }
                elsif ( $char_count % 3 == 1 ) {
                    $sum += $char * 1;
                }
                else {
                    $sum += $char * 7;
                }

                $char_count++;
                last if $char_count == 11;
            }
            $checksum = ( $sum % 11 ) % 10 if $sum;
        }

        if (($length == 15 && $checksum eq $chars[-1]) || ($length != 15 && $checksum eq $chars[11])) {
            $is_fedex = 1;
            $package_number = qq($package_beg$package_number) if $package_beg;
        }
    }

    if ($is_fedex) {
        return $package_number, heading => 'FedEx Shipment Tracking', html => qq(Track this shipment at <a href="http://fedex.com/Tracking?tracknumbers=$package_number&action=track">FedEx</a>.);
    }

    return;
};

1;

__END__

=pod

=head1 NAME

DDG::Goodie::FedEx

=head1 VERSION

version 0.088

=head1 AUTHORS

=over 4

=item *

Gabriel Weinberg <yegg@duckduckgo.com>

=item *

Torsten Raudssus <getty@duckduckgo.com>

=item *

Michael Smith <crazedpsyc@duckduckgo.com>

=item *

Hunter Lang <hunter@duckduckgo.com>

=back

=head1 COPYRIGHT AND LICENSE

This software is copyright (c) 2011 by DuckDuckGo, Inc. L<http://duckduckgo.com/>.

This is free software; you can redistribute it and/or modify it under
the same terms as the Perl 5 programming language system itself.

=cut
