package DDG::Goodie::Epoch;
{
  $DDG::Goodie::Epoch::VERSION = '0.088';
}

use DDG::Goodie;
use Date::Calc qw(Today_and_Now Mktime);

zci is_cached => 1;
zci answer_type => "epoch";

primary_example_queries 'epoch';
description 'Time since the Unix epoch';
name 'epoch';
code_url 'https://github.com/duckduckgo/zeroclickinfo-goodies/blob/master/lib/DDG/Goodie/Epoch.pm';
category 'computing_tools';
topics 'sysadmin';
attribution web => [ 'https://www.duckduckgo.com', 'DuckDuckGo' ],
            github => [ 'https://github.com/duckduckgo', 'duckduckgo'],
            twitter => ['http://twitter.com/duckduckgo', 'duckduckgo'];

triggers query_lc => qr/^epoch$/i;

handle query => sub {
    my ($year, $month, $day, $hour, $min, $sec) = Today_and_Now();
    my $epoch = Mktime($year, $month, $day, $hour, $min, $sec);
    $sec = '0' . $sec  if length($sec) == 1;
    $sec = '0' . $min  if length($min) == 1;
    $sec = '0' . $hour if length($hour) == 1;

    return qq(Unix time: $epoch (for $month/$day/$year $hour:$min:$sec));
};

1;

__END__

=pod

=head1 NAME

DDG::Goodie::Epoch

=head1 VERSION

version 0.088

=head1 AUTHORS

=over 4

=item *

Gabriel Weinberg <yegg@duckduckgo.com>

=item *

Torsten Raudssus <getty@duckduckgo.com>

=item *

Michael Smith <crazedpsyc@duckduckgo.com>

=item *

Hunter Lang <hunter@duckduckgo.com>

=back

=head1 COPYRIGHT AND LICENSE

This software is copyright (c) 2011 by DuckDuckGo, Inc. L<http://duckduckgo.com/>.

This is free software; you can redistribute it and/or modify it under
the same terms as the Perl 5 programming language system itself.

=cut
