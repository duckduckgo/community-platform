package DDG::Goodie::Passphrase;
{
  $DDG::Goodie::Passphrase::VERSION = '0.088';
}

use DDG::Goodie;

triggers start => "passphrase";

primary_example_queries 'passphrase 3';
description 'generate a random passphrase';
name 'Passphrase';
code_url 'https://github.com/duckduckgo/zeroclickinfo-goodies/blob/master/lib/DDG/Goodie/Passphrase.pm';
category 'computing_tools';
topics 'cryptography';

attribution github => ['https://github.com/hunterlang', 'hunterlang'];

my @words = share('words.txt')->slurp;

handle query_parts => sub {
    my $count = @_;
    return unless $count == 3;
    my ( $word_count, $descriptor ) = @_[ 1, 2 ]; 
    return if $word_count < 1;

    my $output = "random passphrase: ";
    for (1..$word_count) {
        my $word = splice @words, (int(rand @words)), 1;
        $output .= "$word ";
    }
    # Remove the trailing space
    chop $output;
    $output =~ s/\n//g;
    return $output;
};

1;

__END__

=pod

=head1 NAME

DDG::Goodie::Passphrase

=head1 VERSION

version 0.088

=head1 AUTHORS

=over 4

=item *

Gabriel Weinberg <yegg@duckduckgo.com>

=item *

Torsten Raudssus <getty@duckduckgo.com>

=item *

Michael Smith <crazedpsyc@duckduckgo.com>

=item *

Hunter Lang <hunter@duckduckgo.com>

=back

=head1 COPYRIGHT AND LICENSE

This software is copyright (c) 2011 by DuckDuckGo, Inc. L<http://duckduckgo.com/>.

This is free software; you can redistribute it and/or modify it under
the same terms as the Perl 5 programming language system itself.

=cut
