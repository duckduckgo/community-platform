package DDG::Goodie::RubiksCubePatterns;
{
  $DDG::Goodie::RubiksCubePatterns::VERSION = '0.088';
}

use DDG::Goodie;

# Create interesting patterns from a solved Rubik's Cube.

primary_example_queries 'rcube stripes';
secondary_example_queries 'rcube cube in a cube', 'rcube swap centers';
description 'create interesting patterns from a solved Rubik\'s Cube';
name 'Rubiks Cube';
code_url 'https://github.com/duckduckgo/zeroclickinfo-goodies/blob/master/lib/DDG/Goodie/RubiksCubePatterns.pm';
category 'random';
topics 'special_interest';

attribution web => ['robert.io', 'Robert Picard'], twitter => '__rlp', github => ['https://github.com/rpicard', 'rpicard'];

triggers start => "rcube", "rubik cube", "rubiks cube", "rubic cube", "rubics cube";

zci is_cached => 1;
zci answer_type => "rubiks_cube";

handle remainder => sub {
	return "F U F R L2 B D' R D2 L D' B R2 L F U F" if lc($_) eq "stripes";
	return "F L F U' R U F2 L2 U' L' B D' B' L2 U" if lc($_) eq "cube in a cube" or lc($_) eq 'in a cube';
	return "U D' R L' F B' U D'" if lc($_) eq "swap centers";
	return;
};

1;

__END__

=pod

=head1 NAME

DDG::Goodie::RubiksCubePatterns

=head1 VERSION

version 0.088

=head1 AUTHORS

=over 4

=item *

Gabriel Weinberg <yegg@duckduckgo.com>

=item *

Torsten Raudssus <getty@duckduckgo.com>

=item *

Michael Smith <crazedpsyc@duckduckgo.com>

=item *

Hunter Lang <hunter@duckduckgo.com>

=back

=head1 COPYRIGHT AND LICENSE

This software is copyright (c) 2011 by DuckDuckGo, Inc. L<http://duckduckgo.com/>.

This is free software; you can redistribute it and/or modify it under
the same terms as the Perl 5 programming language system itself.

=cut
