package DDG::Goodie::Chars;
{
  $DDG::Goodie::Chars::VERSION = '0.088';
}
# ABSTRACT: Give the number of characters (length) of the query.

use DDG::Goodie;

triggers start => 'chars';

zci is_cached => 1;
zci answer_type => "chars";

primary_example_queries 'chars test';
secondary_example_queries 'chars this is a test';
description 'count the number of charaters in a query';
name 'Chars';
code_url 'https://github.com/duckduckgo/zeroclickinfo-goodies/blob/master/lib/DDG/Goodie/Chars.pm';
category 'computing_tools';
topics 'programming';

handle remainder => sub {
    return "Chars: " .length $_ if $_;
    return;
};

1;

__END__

=pod

=head1 NAME

DDG::Goodie::Chars - Give the number of characters (length) of the query.

=head1 VERSION

version 0.088

=head1 AUTHORS

=over 4

=item *

Gabriel Weinberg <yegg@duckduckgo.com>

=item *

Torsten Raudssus <getty@duckduckgo.com>

=item *

Michael Smith <crazedpsyc@duckduckgo.com>

=item *

Hunter Lang <hunter@duckduckgo.com>

=back

=head1 COPYRIGHT AND LICENSE

This software is copyright (c) 2011 by DuckDuckGo, Inc. L<http://duckduckgo.com/>.

This is free software; you can redistribute it and/or modify it under
the same terms as the Perl 5 programming language system itself.

=cut
