package DDG::Goodie::Unidecode;
{
  $DDG::Goodie::Unidecode::VERSION = '0.088';
}
# ABSTRACT: return an ASCII version of the search query

use DDG::Goodie;
use Text::Unidecode;
use utf8;

triggers startend => "unidecode";

zci is_cached => 1;
zci answer_type => "convert_to_ascii";

attribution github => ['https://github.com/moritz', 'moritz'];
primary_example_queries 'unidecode møæp';
secondary_example_queries "unidecode åäº°";
description 'decode special non-latin characters';
code_url 'https://github.com/duckduckgo/zeroclickinfo-goodies/blob/master/lib/DDG/Goodie/Unidecode.pm';
category 'computing_tools';
topics 'programming';

handle remainder => sub {
    my $u = unidecode $_;
    # unidecode output sometimes contains trailing spaces
    $u =~ s/\s+$//;
    return $u;
};

1;

__END__

=pod

=head1 NAME

DDG::Goodie::Unidecode - return an ASCII version of the search query

=head1 VERSION

version 0.088

=head1 AUTHORS

=over 4

=item *

Gabriel Weinberg <yegg@duckduckgo.com>

=item *

Torsten Raudssus <getty@duckduckgo.com>

=item *

Michael Smith <crazedpsyc@duckduckgo.com>

=item *

Hunter Lang <hunter@duckduckgo.com>

=back

=head1 COPYRIGHT AND LICENSE

This software is copyright (c) 2011 by DuckDuckGo, Inc. L<http://duckduckgo.com/>.

This is free software; you can redistribute it and/or modify it under
the same terms as the Perl 5 programming language system itself.

=cut
