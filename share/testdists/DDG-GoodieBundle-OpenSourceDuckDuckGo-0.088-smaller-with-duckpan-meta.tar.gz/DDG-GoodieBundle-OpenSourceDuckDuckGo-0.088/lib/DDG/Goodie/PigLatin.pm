package DDG::Goodie::PigLatin;
{
  $DDG::Goodie::PigLatin::VERSION = '0.088';
}

use DDG::Goodie;
use Lingua::PigLatin 'piglatin';

triggers startend => 'pig latin', 'piglatin';

zci is_cached => 1;
zci answer_type => "translation";

attribution github => ['http://github.com/nospampleasemam', 'nospampleasemam'],
            web => ['http://github.com/nospampleasemam', 'nospampleasemam'];

primary_example_queries 'pig latin i love duckduckgo';
name 'PigLatin';
description 'translate a phrase into pig latin';
code_url 'https://github.com/duckduckgo/zeroclickinfo-goodies/blob/master/lib/DDG/Goodie/PigLatin.pm';
category 'conversions';
topics 'words_and_games';

handle remainder => sub {
    return "Pig Latin: " . piglatin($_)
};

1;

__END__

=pod

=head1 NAME

DDG::Goodie::PigLatin

=head1 VERSION

version 0.088

=head1 AUTHORS

=over 4

=item *

Gabriel Weinberg <yegg@duckduckgo.com>

=item *

Torsten Raudssus <getty@duckduckgo.com>

=item *

Michael Smith <crazedpsyc@duckduckgo.com>

=item *

Hunter Lang <hunter@duckduckgo.com>

=back

=head1 COPYRIGHT AND LICENSE

This software is copyright (c) 2011 by DuckDuckGo, Inc. L<http://duckduckgo.com/>.

This is free software; you can redistribute it and/or modify it under
the same terms as the Perl 5 programming language system itself.

=cut
