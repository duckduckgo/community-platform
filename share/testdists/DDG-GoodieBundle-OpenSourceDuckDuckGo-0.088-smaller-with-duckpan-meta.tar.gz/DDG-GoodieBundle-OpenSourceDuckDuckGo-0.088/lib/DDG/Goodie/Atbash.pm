package DDG::Goodie::Atbash;
{
  $DDG::Goodie::Atbash::VERSION = '0.088';
}
# ABSTRACT: A simple substitution cipher using a reversed alphabet

use DDG::Goodie;

primary_example_queries 'atbash hello';
secondary_example_queries 'atbash svool';
description 'A simple substitution cipher using a reversed alphabet';
name 'Atbash';
code_url 'https://github.com/duckduckgo/zeroclickinfo-goodies/blob/master/lib/DDG/Goodie/Atbash.pm';
category 'transformations';
topics 'cryptography';

attribution web => ['http://kyokodaniel.com/tech/', 'Daniel Davis'],
            github => ['https://github.com/tagawa', 'tagawa'],
            twitter => ['https://twitter.com/ourmaninjapan', 'ourmaninjapan'];

triggers start => 'atbash';

zci is_cached => 1;

handle remainder => sub {
    if ($_) {
        my $char;
        my $result;
        
        while (/(.)/g) {
            if ($1 =~ /([a-z])/) {
                # Substitute lowercase characters
                $char = chr(219 - ord $1);
            }
            elsif ($1 =~ /([A-Z])/) {
                # Substitute uppercase characters
                $char = chr(155 - ord $1);
            }
            else { $char = $1; }
            $result .= $char;
        }
        
        return "Atbash: $result";
    }
    return;
};

1;

__END__

=pod

=head1 NAME

DDG::Goodie::Atbash - A simple substitution cipher using a reversed alphabet

=head1 VERSION

version 0.088

=head1 AUTHORS

=over 4

=item *

Gabriel Weinberg <yegg@duckduckgo.com>

=item *

Torsten Raudssus <getty@duckduckgo.com>

=item *

Michael Smith <crazedpsyc@duckduckgo.com>

=item *

Hunter Lang <hunter@duckduckgo.com>

=back

=head1 COPYRIGHT AND LICENSE

This software is copyright (c) 2011 by DuckDuckGo, Inc. L<http://duckduckgo.com/>.

This is free software; you can redistribute it and/or modify it under
the same terms as the Perl 5 programming language system itself.

=cut
