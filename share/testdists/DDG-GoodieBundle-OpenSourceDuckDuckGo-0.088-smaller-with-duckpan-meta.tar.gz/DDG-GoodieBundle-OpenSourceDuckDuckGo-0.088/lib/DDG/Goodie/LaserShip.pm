package DDG::Goodie::LaserShip;
{
  $DDG::Goodie::LaserShip::VERSION = '0.088';
}

use DDG::Goodie;

zci is_cached => 1;
zci answer_type => "lasership";

primary_example_queries 'LL12345678';
description 'Track a package from Lasership';
name 'Lasership';
code_url 'https://github.com/duckduckgo/zeroclickinfo-goodies/blob/master/lib/DDG/Goodie/LaserShip.pm';
category 'ids';
topics 'special_interest';
attribution web => [ 'https://www.duckduckgo.com', 'DuckDuckGo' ],
            github => [ 'https://github.com/duckduckgo', 'duckduckgo'],
            twitter => ['http://twitter.com/duckduckgo', 'duckduckgo'];

triggers query_nowhitespace_nodash => qr/(l[a-z]\d{8})/i;

handle query_nowhitespace_nodash => sub {
    return $1, heading => "Lasership Shipment Tracking", html => qq(Track this shipment at <a href="http://lasership.com/track/$1">Lasership</a>.) if $1;
    return;
};

1;

__END__

=pod

=head1 NAME

DDG::Goodie::LaserShip

=head1 VERSION

version 0.088

=head1 AUTHORS

=over 4

=item *

Gabriel Weinberg <yegg@duckduckgo.com>

=item *

Torsten Raudssus <getty@duckduckgo.com>

=item *

Michael Smith <crazedpsyc@duckduckgo.com>

=item *

Hunter Lang <hunter@duckduckgo.com>

=back

=head1 COPYRIGHT AND LICENSE

This software is copyright (c) 2011 by DuckDuckGo, Inc. L<http://duckduckgo.com/>.

This is free software; you can redistribute it and/or modify it under
the same terms as the Perl 5 programming language system itself.

=cut
