package DDG::Goodie::GUID;
{
  $DDG::Goodie::GUID::VERSION = '0.088';
}

use DDG::Goodie;
use Data::GUID;

triggers start => 'globally', 'universally', 'rfc', 'guid', 'uuid';

zci answer_type => "guid";

primary_example_queries 'guid';
secondary_example_queries 'uuid';
description 'generate a unique indentifier';
name 'GUID';
code_url 'https://github.com/duckduckgo/zeroclickinfo-goodies/blob/master/lib/DDG/Goodie/GUID.pm';
category 'computing_tools';
topics 'programming';
attribution twitter => 'crazedpsyc',
            cpan    => 'CRZEDPSYC' ;

my %guid = (
    'guid' => 0,
    'uuid' => 1,
    'globally unique identifier' => 0,
    'universally unique identifier' => 1,
    'rfc 4122' => 0,
    );

handle query_lc => sub {
    return unless exists $guid{$_};
    if (my $guid = Data::GUID->new) {
        if ($guid{$_}) {
            $guid = lc $guid;
        } else {
            $guid = qq({$guid});
        }
	$guid .= ' (randomly generated)';
        return $guid;
    }
    return;
};
1;

__END__

=pod

=head1 NAME

DDG::Goodie::GUID

=head1 VERSION

version 0.088

=head1 AUTHORS

=over 4

=item *

Gabriel Weinberg <yegg@duckduckgo.com>

=item *

Torsten Raudssus <getty@duckduckgo.com>

=item *

Michael Smith <crazedpsyc@duckduckgo.com>

=item *

Hunter Lang <hunter@duckduckgo.com>

=back

=head1 COPYRIGHT AND LICENSE

This software is copyright (c) 2011 by DuckDuckGo, Inc. L<http://duckduckgo.com/>.

This is free software; you can redistribute it and/or modify it under
the same terms as the Perl 5 programming language system itself.

=cut
