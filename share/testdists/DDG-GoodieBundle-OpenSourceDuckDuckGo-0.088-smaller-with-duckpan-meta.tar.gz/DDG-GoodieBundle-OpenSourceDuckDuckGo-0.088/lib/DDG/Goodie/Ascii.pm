package DDG::Goodie::Ascii;
{
  $DDG::Goodie::Ascii::VERSION = '0.088';
}
# ABSTRACT: ASCII

use DDG::Goodie;

triggers end => "ascii";

primary_example_queries '0110100001100101011011000110110001101111 to ascii';
description 'convert binary data to readable characters';
name 'Ascii';
code_url 'https://github.com/duckduckgo/zeroclickinfo-goodies/blob/master/lib/DDG/Goodie/Binary.pm';
category 'transformations';
topics 'cryptography';

zci answer_type => "ascii_conversion";
zci is_cached => 1;

handle remainder => sub {
    my $ascii = pack("B*", $1) if /^(([0-1]{8})*)\s+(in|to)$/; 
    return "$1 in binary is \"$ascii\" in ASCII" if $ascii;
    return;
};

1;

__END__

=pod

=head1 NAME

DDG::Goodie::Ascii - ASCII

=head1 VERSION

version 0.088

=head1 AUTHORS

=over 4

=item *

Gabriel Weinberg <yegg@duckduckgo.com>

=item *

Torsten Raudssus <getty@duckduckgo.com>

=item *

Michael Smith <crazedpsyc@duckduckgo.com>

=item *

Hunter Lang <hunter@duckduckgo.com>

=back

=head1 COPYRIGHT AND LICENSE

This software is copyright (c) 2011 by DuckDuckGo, Inc. L<http://duckduckgo.com/>.

This is free software; you can redistribute it and/or modify it under
the same terms as the Perl 5 programming language system itself.

=cut
