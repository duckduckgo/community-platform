package DDG::Goodie::Unicornify;
{
  $DDG::Goodie::Unicornify::VERSION = '0.088';
}
# ABSTRACT: Return Gravatar image given an email address 

use DDG::Goodie;
use CGI qw/img/;
use Email::Valid;
use Unicornify::URL;

triggers start => 'unicornify';
attribution github => ['https://github.com/flaming-toast', 'flaming-toast'];

handle remainder => sub {
	my $link = 'http://unicornify.appspot.com/';
	if (Email::Valid->address($_)) {
		s/[\s\t]+//g; # strip whitespace from the remainder, we just need the email address.
		my $answer = 'This is a unique unicorn for ' . $_ . ':' . "\nLearn more at unicornify.appspot.com"; 
		my $heading =  $_ . ' (Unicornify)';
		my $html = 'This is a unique unicorn for ' . $_ . ':'
		.'<br /><a href="' . unicornify_url(email => $_, size => 128) .'">'
		.'<img src="/iu/?u='.unicornify_url(email => $_, size => "100").'" style="margin: 10px 0px 10px 20px; border-radius: 8px;" /></a>'
		. 'Learn more at <a href="'.$link.'">unicornify.appspot.com</a>';
		
		return $answer, heading => $heading, html => $html;
	}
	return;
};

zci is_cached => 1;

1;

__END__

=pod

=head1 NAME

DDG::Goodie::Unicornify - Return Gravatar image given an email address 

=head1 VERSION

version 0.088

=head1 AUTHORS

=over 4

=item *

Gabriel Weinberg <yegg@duckduckgo.com>

=item *

Torsten Raudssus <getty@duckduckgo.com>

=item *

Michael Smith <crazedpsyc@duckduckgo.com>

=item *

Hunter Lang <hunter@duckduckgo.com>

=back

=head1 COPYRIGHT AND LICENSE

This software is copyright (c) 2011 by DuckDuckGo, Inc. L<http://duckduckgo.com/>.

This is free software; you can redistribute it and/or modify it under
the same terms as the Perl 5 programming language system itself.

=cut
