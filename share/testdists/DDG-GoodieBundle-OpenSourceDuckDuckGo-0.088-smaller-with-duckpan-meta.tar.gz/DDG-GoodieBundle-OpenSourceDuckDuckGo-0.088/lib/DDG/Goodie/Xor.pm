package DDG::Goodie::Xor;
{
  $DDG::Goodie::Xor::VERSION = '0.088';
}

use DDG::Goodie;
use utf8;

triggers any => 'xor', '⊕';

zci is_cached => 1;
zci answer_type => "xor";

attribution
    github => ['https://github.com/MithrandirAgain', 'MithrandirAgain'];

primary_example_queries '4 xor 5';
secondary_example_queries '5 ⊕ 79', '9489 xor 394 xor 9349 xor 39 xor 29 xor 4967 xor 3985';
description 'take two numbers and do a bitwise exclusive-or operation on them';
code_url 'https://github.com/duckduckgo/zeroclickinfo-goodies/blob/master/lib/DDG/Goodie/Xor.pm';
category 'calculations';
topics 'math';

handle query_raw => sub {
    my @nums = grep(!/(xor|⊕)/, split(/\s+(⊕|xor)\s+/i, $_));
    my $num = 0;
    foreach (@nums) {
        $num ^= $_ if /^\d+$/;
        return unless /^\d+$/;
    }
    return "$num" if $num;
    return;
};

1;

__END__

=pod

=head1 NAME

DDG::Goodie::Xor

=head1 VERSION

version 0.088

=head1 AUTHORS

=over 4

=item *

Gabriel Weinberg <yegg@duckduckgo.com>

=item *

Torsten Raudssus <getty@duckduckgo.com>

=item *

Michael Smith <crazedpsyc@duckduckgo.com>

=item *

Hunter Lang <hunter@duckduckgo.com>

=back

=head1 COPYRIGHT AND LICENSE

This software is copyright (c) 2011 by DuckDuckGo, Inc. L<http://duckduckgo.com/>.

This is free software; you can redistribute it and/or modify it under
the same terms as the Perl 5 programming language system itself.

=cut
