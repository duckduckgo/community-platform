package DDG::Goodie::BirthStone;
{
  $DDG::Goodie::BirthStone::VERSION = '0.088';
}
#Returns the birthstone of the queried month

use DDG::Goodie;

triggers startend => 'birthstone', 'birth stone';

zci answer_type => "BirthStone";
zci is_cached => 1;

primary_example_queries 'birthstone april';
secondary_example_queries 'may birth stone';
description 'returns the birth stone of the specified month';
name 'BirthStone';
topics 'special_interest', 'entertainment';
category 'random';
attribution github => [ 'https://github.com/austinheimark', 'austin_heimark' ];

my %birthstones = ( 
	"january" => "Garnet",
	"february" => "Amethyst",
	"march" => "Aquamarine",
	"april" => "Diamond",
	"may" => "Emerald",
	"june" => "Pearl",
	"july" => "Ruby",
	"august" => "Peridot",
	"september" => "Sapphire",
	"october" => "Opal",
	"november" => "Topaz",
	"december" => "Turquoise"
);

handle remainder => sub {
	my $month = lc $_;
	my $stone = $birthstones{$month};
	return ucfirst $month . " birthstone: $stone" if $stone;
	return;
};

1;

__END__

=pod

=head1 NAME

DDG::Goodie::BirthStone

=head1 VERSION

version 0.088

=head1 AUTHORS

=over 4

=item *

Gabriel Weinberg <yegg@duckduckgo.com>

=item *

Torsten Raudssus <getty@duckduckgo.com>

=item *

Michael Smith <crazedpsyc@duckduckgo.com>

=item *

Hunter Lang <hunter@duckduckgo.com>

=back

=head1 COPYRIGHT AND LICENSE

This software is copyright (c) 2011 by DuckDuckGo, Inc. L<http://duckduckgo.com/>.

This is free software; you can redistribute it and/or modify it under
the same terms as the Perl 5 programming language system itself.

=cut
