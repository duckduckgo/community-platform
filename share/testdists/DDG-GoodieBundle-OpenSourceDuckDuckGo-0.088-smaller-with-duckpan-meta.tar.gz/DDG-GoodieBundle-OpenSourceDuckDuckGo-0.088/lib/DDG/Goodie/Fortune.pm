package DDG::Goodie::Fortune;
{
  $DDG::Goodie::Fortune::VERSION = '0.088';
}

use DDG::Goodie;
use Fortune;

triggers any => 'unix fortune','unix fortune!','fortune cookie','fortune cookie!';

primary_example_queries 'unix fortune cookie';
name 'Fortune';
description 'get a random phrase from the original fortunes file';
code_url 'https://github.com/duckduckgo/zeroclickinfo-goodies/blob/master/lib/DDG/Goodie/Fortune.pm';
category 'random';
topics 'words_and_games';
attribution github => ['https://github.com/frncscgmz', 'frncscgmz'];

zci is_cached => 0;
zci answer_type => "fortune";

handle remainder => sub {
   my $ffile = share('fortunes');
   my $fortune_file = Fortune->new($ffile);
   $fortune_file->read_header();
   my $output = $fortune_file->get_random_fortune();
   $output =~ s/\n//g;
   return $output;
};

1;

__END__

=pod

=head1 NAME

DDG::Goodie::Fortune

=head1 VERSION

version 0.088

=head1 AUTHORS

=over 4

=item *

Gabriel Weinberg <yegg@duckduckgo.com>

=item *

Torsten Raudssus <getty@duckduckgo.com>

=item *

Michael Smith <crazedpsyc@duckduckgo.com>

=item *

Hunter Lang <hunter@duckduckgo.com>

=back

=head1 COPYRIGHT AND LICENSE

This software is copyright (c) 2011 by DuckDuckGo, Inc. L<http://duckduckgo.com/>.

This is free software; you can redistribute it and/or modify it under
the same terms as the Perl 5 programming language system itself.

=cut
