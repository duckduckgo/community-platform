package DDG::Goodie::Morse;
{
  $DDG::Goodie::Morse::VERSION = '0.088';
}
# ABSTRACT: Converts to/from Morse code

use DDG::Goodie;
use Convert::Morse qw(is_morse as_ascii as_morse);

primary_example_queries 'morse ... --- ...';
secondary_example_queries 'morse SOS';
description 'convert to and from morse code';
name 'Morse';
code_url 'https://github.com/duckduckgo/zeroclickinfo-goodies/blob/master/lib/DDG/Goodie/Morse.pm';
category 'conversions';
topics 'special_interest';
attribution
  web     => 'http://und3f.com',
  twitter => 'und3f',
  github  => 'und3f',
  cpan    => 'UNDEF';

triggers startend => 'morse', 'morse code';

zci is_cached => 1;
zci answer_type => 'chars';

handle remainder => sub {
    return unless $_;

    my $convertor = is_morse($_) ? \&as_ascii : \&as_morse;
    return "Morse code: " . $convertor->($_);
};

1;

__END__

=pod

=head1 NAME

DDG::Goodie::Morse - Converts to/from Morse code

=head1 VERSION

version 0.088

=head1 AUTHORS

=over 4

=item *

Gabriel Weinberg <yegg@duckduckgo.com>

=item *

Torsten Raudssus <getty@duckduckgo.com>

=item *

Michael Smith <crazedpsyc@duckduckgo.com>

=item *

Hunter Lang <hunter@duckduckgo.com>

=back

=head1 COPYRIGHT AND LICENSE

This software is copyright (c) 2011 by DuckDuckGo, Inc. L<http://duckduckgo.com/>.

This is free software; you can redistribute it and/or modify it under
the same terms as the Perl 5 programming language system itself.

=cut
