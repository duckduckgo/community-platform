package DDG::Goodie::Rafl;
{
  $DDG::Goodie::Rafl::VERSION = '0.088';
}
# ABSTRACT: rafl is so everywhere, there's a DuckDuckGo.com "!rafl" bang syntax
use DDG::Goodie;

use Acme::rafl::Everywhere;

primary_example_queries 'rafl is everywhere';
secondary_example_queries 'where is rafl?';
description 'rafl is everywhere!';
name 'rafl';
code_url 'https://github.com/duckduckgo/zeroclickinfo-goodies/blob/master/lib/DDG/Goodie/.pm';
category 'ids';
topics 'social';

attribution
  web     => 'http://stephen.scaffidi.net',
  github  => ['https://github.com/Hercynium', 'Hercynium'];

triggers any => 'rafl';

handle remainder => sub {
  return Acme::rafl::Everywhere->new->fact
};

1 && "rafl"; # everywhere

__END__

=pod

=head1 NAME

DDG::Goodie::Rafl - rafl is so everywhere, there's a DuckDuckGo.com "!rafl" bang syntax

=head1 VERSION

version 0.088

=head1 AUTHORS

=over 4

=item *

Gabriel Weinberg <yegg@duckduckgo.com>

=item *

Torsten Raudssus <getty@duckduckgo.com>

=item *

Michael Smith <crazedpsyc@duckduckgo.com>

=item *

Hunter Lang <hunter@duckduckgo.com>

=back

=head1 COPYRIGHT AND LICENSE

This software is copyright (c) 2011 by DuckDuckGo, Inc. L<http://duckduckgo.com/>.

This is free software; you can redistribute it and/or modify it under
the same terms as the Perl 5 programming language system itself.

=cut
