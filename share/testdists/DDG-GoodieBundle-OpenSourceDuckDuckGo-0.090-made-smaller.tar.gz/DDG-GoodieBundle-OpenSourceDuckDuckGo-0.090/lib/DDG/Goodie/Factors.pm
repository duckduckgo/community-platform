package DDG::Goodie::Factors;
{
  $DDG::Goodie::Factors::VERSION = '0.090';
}
#Returns the factors of the entered number

use DDG::Goodie;
use Math::Prime::Util 'all_factors';

zci answer_type => "factors";
zci is_cached => 1;

triggers startend => 'factors', 'factors of';

primary_example_queries 'factors of 30';
secondary_example_queries '72 factors';
description 'Returns the factors of the entered number';
name 'Factors';
topics 'math';
category 'calculations';
attribution github => [ 'https://github.com/austinheimark', 'austin_heimark' ];

handle remainder => sub {
	return unless /^\d+$/; 
	my @factors = all_factors($_);
	return "Factors of $_: 1 @factors $_";
};

1;

__END__

=pod

=head1 NAME

DDG::Goodie::Factors

=head1 VERSION

version 0.090

=head1 AUTHORS

=over 4

=item *

Gabriel Weinberg <yegg@duckduckgo.com>

=item *

Torsten Raudssus <getty@duckduckgo.com>

=item *

Michael Smith <crazedpsyc@duckduckgo.com>

=item *

Hunter Lang <hunter@duckduckgo.com>

=back

=head1 COPYRIGHT AND LICENSE

This software is copyright (c) 2011 by DuckDuckGo, Inc. L<http://duckduckgo.com/>.

This is free software; you can redistribute it and/or modify it under
the same terms as the Perl 5 programming language system itself.

=cut
