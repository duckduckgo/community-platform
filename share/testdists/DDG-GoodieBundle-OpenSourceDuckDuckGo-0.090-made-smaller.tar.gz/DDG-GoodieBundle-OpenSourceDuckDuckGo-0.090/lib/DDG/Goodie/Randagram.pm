package DDG::Goodie::Randagram;
{
  $DDG::Goodie::Randagram::VERSION = '0.090';
}
# ABSTRACT: Take a query and spit it out randomly.

use DDG::Goodie;
use List::Util 'shuffle'; 

triggers start => "randagram";

zci is_cached => 0;
zci answer_type => "randagram";

primary_example_queries "randagram jazz hands";
description "mix up the letters of your query";
name "Randagram";
code_url "https://github.com/duckduckgo/zeroclickinfo-goodies/blob/master/lib/DDG/Goodie/Randagram.pm";
category "transformations";
topics "words_and_games";

attribution github => ["https://github.com/crazedpsyc", "crazedpsyc"];

handle remainder => sub {
    s/^of\s(.*)/$1/i;
    my @chars = split(//, $_); #convert each character of the query to an array element
    my @garbledChars = shuffle(@chars); #randomly reorder the array
    my $garbledAnswer = join('',@garbledChars); #convert array to string
    return "Randagram of \"$_\": $garbledAnswer";
};

zci is_cached => 0;

1;

__END__

=pod

=head1 NAME

DDG::Goodie::Randagram - Take a query and spit it out randomly.

=head1 VERSION

version 0.090

=head1 AUTHORS

=over 4

=item *

Gabriel Weinberg <yegg@duckduckgo.com>

=item *

Torsten Raudssus <getty@duckduckgo.com>

=item *

Michael Smith <crazedpsyc@duckduckgo.com>

=item *

Hunter Lang <hunter@duckduckgo.com>

=back

=head1 COPYRIGHT AND LICENSE

This software is copyright (c) 2011 by DuckDuckGo, Inc. L<http://duckduckgo.com/>.

This is free software; you can redistribute it and/or modify it under
the same terms as the Perl 5 programming language system itself.

=cut
