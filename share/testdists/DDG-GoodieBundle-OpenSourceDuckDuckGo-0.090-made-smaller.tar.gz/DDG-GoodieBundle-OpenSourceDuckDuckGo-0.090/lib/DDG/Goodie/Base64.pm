package DDG::Goodie::Base64;
{
  $DDG::Goodie::Base64::VERSION = '0.090';
}

use DDG::Goodie;
use MIME::Base64; 
use Encode;

triggers startend => "base64";

zci answer_type => "base64_conversion";

zci is_cached => 1;

primary_example_queries 'base64 encode foo';
secondary_example_queries 'base64 decode dGhpcyB0ZXh0';
description 'encode to and decode from base64';
name 'Base64';
code_url 'https://github.com/duckduckgo/zeroclickinfo-goodies/blob/master/lib/DDG/Goodie/Base64.pm';
category 'conversions';
topics 'programming';
attribution web => [ 'robert.io', 'Robert Picard' ],
            github => [ 'http://github.com/rpicard', 'rpicard'],
            twitter => ['http://twitter.com/__rlp', '__rlp'];

handle remainder => sub {
	return unless $_ =~ /^(encode|decode|)\s*(.*)$/i;

	my $command = $1 || '';
	my $str = $2 || '';

	if ($str) {

		if ( $command && $command eq 'decode' ) {

			$str = decode_base64($str);
			$str = decode( "UTF-8", $str );
            chomp $str;

			return "Base64 decoded: $str"; 
		}
		else {
			$str = encode_base64( encode( "UTF-8", $str ) );
            chomp $str;

			return "Base64 encoded: $str";
		}

	}

	return;
};

1;

__END__

=pod

=head1 NAME

DDG::Goodie::Base64

=head1 VERSION

version 0.090

=head1 AUTHORS

=over 4

=item *

Gabriel Weinberg <yegg@duckduckgo.com>

=item *

Torsten Raudssus <getty@duckduckgo.com>

=item *

Michael Smith <crazedpsyc@duckduckgo.com>

=item *

Hunter Lang <hunter@duckduckgo.com>

=back

=head1 COPYRIGHT AND LICENSE

This software is copyright (c) 2011 by DuckDuckGo, Inc. L<http://duckduckgo.com/>.

This is free software; you can redistribute it and/or modify it under
the same terms as the Perl 5 programming language system itself.

=cut
