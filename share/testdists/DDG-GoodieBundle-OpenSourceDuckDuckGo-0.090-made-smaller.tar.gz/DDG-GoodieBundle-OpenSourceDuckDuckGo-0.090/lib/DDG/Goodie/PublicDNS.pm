package DDG::Goodie::PublicDNS;
{
  $DDG::Goodie::PublicDNS::VERSION = '0.090';
}

use DDG::Goodie;

primary_example_queries 'public dns';
description 'list common public DNS servers and their IP addresses';
name 'Public DNS';
code_url 'https://github.com/duckduckgo/zeroclickinfo-goodies/blob/master/lib/DDG/Goodie/PublicDNS.pm';
category 'cheat_sheets';
topics 'sysadmin';

attribution github => ['https://github.com/warthurton', 'warthurton'];

triggers end => "public dns", "dns servers";

zci is_cached => 1;
zci answer_type => "public_dns";

my $text = share('publicdns.txt')->slurp;
my $html = share('publicdns.html')->slurp;

handle sub {
    $text, html => $html;
};

1;

__END__

=pod

=head1 NAME

DDG::Goodie::PublicDNS

=head1 VERSION

version 0.090

=head1 AUTHORS

=over 4

=item *

Gabriel Weinberg <yegg@duckduckgo.com>

=item *

Torsten Raudssus <getty@duckduckgo.com>

=item *

Michael Smith <crazedpsyc@duckduckgo.com>

=item *

Hunter Lang <hunter@duckduckgo.com>

=back

=head1 COPYRIGHT AND LICENSE

This software is copyright (c) 2011 by DuckDuckGo, Inc. L<http://duckduckgo.com/>.

This is free software; you can redistribute it and/or modify it under
the same terms as the Perl 5 programming language system itself.

=cut
