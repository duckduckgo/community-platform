package DDG::Goodie::Rot13;
{
  $DDG::Goodie::Rot13::VERSION = '0.090';
}
# ABSTRACT: Rotate chars by 13  letters

use DDG::Goodie;

primary_example_queries 'rot13 thirteen';
secondary_example_queries 'rot13 guvegrra';
description 'rotate all the letters in your query by 13';
name 'Rot13';
code_url 'https://github.com/duckduckgo/zeroclickinfo-goodies/blob/master/lib/DDG/Goodie/Rot13.pm';
category 'transformations';
topics 'cryptography';

attribution github => ['https://github.com/unlisted', 'unlisted'];

triggers start => 'rot13';

zci is_cached => 1;

handle remainder => sub {
    if ($_) {
        $_ =~ tr[a-zA-Z][n-za-mN-ZA-M]; 
        return "ROT13: $_";
    };
    return;
};

1;

__END__

=pod

=head1 NAME

DDG::Goodie::Rot13 - Rotate chars by 13  letters

=head1 VERSION

version 0.090

=head1 AUTHORS

=over 4

=item *

Gabriel Weinberg <yegg@duckduckgo.com>

=item *

Torsten Raudssus <getty@duckduckgo.com>

=item *

Michael Smith <crazedpsyc@duckduckgo.com>

=item *

Hunter Lang <hunter@duckduckgo.com>

=back

=head1 COPYRIGHT AND LICENSE

This software is copyright (c) 2011 by DuckDuckGo, Inc. L<http://duckduckgo.com/>.

This is free software; you can redistribute it and/or modify it under
the same terms as the Perl 5 programming language system itself.

=cut
