package DDG::Goodie::TitleCase;
{
  $DDG::Goodie::TitleCase::VERSION = '0.090';
}

use DDG::Goodie;

triggers startend => 'titlecase', 'ucfirst', 'title case';

primary_example_queries 'titlecase test';
description 'return the query in title case';
name 'Title Case';
code_url 'https://github.com/duckduckgo/zeroclickinfo-goodies/blob/master/lib/DDG/Goodie/TitleCase.pm';
category 'transformations';
topics 'words_and_games';

attribution github => ['https://github.com/moollaza', 'moollaza'];

zci is_cached => 1;
zci answer_type => "title_case";

handle remainder => sub { join(' ', map { ucfirst $_ } split(/ /, $_))};

1;

__END__

=pod

=head1 NAME

DDG::Goodie::TitleCase

=head1 VERSION

version 0.090

=head1 AUTHORS

=over 4

=item *

Gabriel Weinberg <yegg@duckduckgo.com>

=item *

Torsten Raudssus <getty@duckduckgo.com>

=item *

Michael Smith <crazedpsyc@duckduckgo.com>

=item *

Hunter Lang <hunter@duckduckgo.com>

=back

=head1 COPYRIGHT AND LICENSE

This software is copyright (c) 2011 by DuckDuckGo, Inc. L<http://duckduckgo.com/>.

This is free software; you can redistribute it and/or modify it under
the same terms as the Perl 5 programming language system itself.

=cut
