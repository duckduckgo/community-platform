package DDG::Goodie::Sha;
{
  $DDG::Goodie::Sha::VERSION = '0.090';
}

use DDG::Goodie;
use Digest::SHA;

zci is_cached => 1;
zci answer_type => "sha";

primary_example_queries 'SHA this';
secondary_example_queries 'sha-512 that', 'sha512sum dim-dims';
description 'SHA hash cryptography';
name 'SHA';
code_url 'https://github.com/duckduckgo/zeroclickinfo-goodies/blob/master/lib/DDG/Goodie/Sha.pm';
category 'calculations';
topics 'math';
attribution web => [ 'https://www.duckduckgo.com', 'DuckDuckGo' ],
            github => [ 'https://github.com/duckduckgo', 'duckduckgo'],
            twitter => ['http://twitter.com/duckduckgo', 'duckduckgo'];


triggers query_lc => qr/^sha\-?(1|224|256|384|512|)(?:sum|) (hex|base64|)\s*(.*)$/i;

handle query => sub {
	my $command1 = $1 || '';
	my $command2 = $2 || '';
	my $str      = $3 || '';

	if($str) {
		if ( $command1 eq '224' ) {
		    $str = $command2 eq 'base64' ? Digest::SHA::sha224_base64($str) : Digest::SHA::sha224_hex($str);
		}
		elsif ( $command1 eq '256' ) {
		    $str = $command2 eq 'base64' ? Digest::SHA::sha256_base64($str) : Digest::SHA::sha256_hex($str);
		}
		elsif ( $command1 eq '384' ) {
		    $str = $command2 eq 'base64' ? Digest::SHA::sha384_base64($str) : Digest::SHA::sha384_hex($str);
		}
		elsif ( $command1 eq '512' ) {
		    $str = $command2 eq 'base64' ? Digest::SHA::sha512_base64($str) : Digest::SHA::sha512_hex($str);
		}
		else {
		    $command1 = '1';
		    $str = $command2 eq 'base64' ? Digest::SHA::sha1_base64($str) : Digest::SHA::sha1_hex($str);
		}

		return $str, heading => "SHA-$command1 hash";
	}

	return;
};

1;

__END__

=pod

=head1 NAME

DDG::Goodie::Sha

=head1 VERSION

version 0.090

=head1 AUTHORS

=over 4

=item *

Gabriel Weinberg <yegg@duckduckgo.com>

=item *

Torsten Raudssus <getty@duckduckgo.com>

=item *

Michael Smith <crazedpsyc@duckduckgo.com>

=item *

Hunter Lang <hunter@duckduckgo.com>

=back

=head1 COPYRIGHT AND LICENSE

This software is copyright (c) 2011 by DuckDuckGo, Inc. L<http://duckduckgo.com/>.

This is free software; you can redistribute it and/or modify it under
the same terms as the Perl 5 programming language system itself.

=cut
