package DDG::Goodie::HTMLEntities;
{
  $DDG::Goodie::HTMLEntities::VERSION = '0.090';
}
# ABSTRACT: Decode HTML Entities.

use DDG::Goodie;
use HTML::Entities;
use Unicode::UCD 'charinfo';

zci answer_type => 'html_entity';

zci is_cached => 1;

triggers query_nowhitespace => qr/^(?:html|entity|htmlentity)?(&#?\w+;?)$/i;

primary_example_queries '&#33;';
secondary_example_queries 'html entity &amp;';
description 'decode HTML entities';
name 'HTMLEntities';
code_url 'https://github.com/duckduckgo/zeroclickinfo-goodies/blob/master/lib/DDG/Goodie/HTMLEntities.pm';
category 'computing_tools';
topics 'programming';
attribution twitter => 'crazedpsyc',
            cpan    => 'CRZEDPSYC' ;

handle matches => sub {
    my $entity = $_[0];
    $entity =~ s/;?$/;/; # append a semicolon (some entities like &mdash do not work without one)
    my $decoded = decode_entities($entity);
    my $decoded_html = $decoded;
    my $decimal = ord($decoded);

    my $info = charinfo($decimal);
    if( $$info{name} eq '<control>' ) {
        $decoded_html = "<a href='https://en.wikipedia.org/wiki/Unicode_control_characters'>Unicode control character</a> (no visual representation)";
        $decoded = "Unicode control character (no visual representation)";
    } 
    elsif(substr($$info{category},0,1) eq 'C') {
        $decoded = "Special character (no visual representation)";
        $decoded_html = "Special character (no visual representation)";
    }
    

    my $hex = sprintf("%04x", $decimal);
    return "Decoded HTML Entity: $decoded, decimal: $decimal, hexadecimal: $hex", 
           html => "Decoded HTML Entity: $decoded_html, decimal: $decimal, hexadecimal: <a href=\"/?q=U%2B$hex\">$hex</a>" unless $entity eq $decoded; # decode_entities will return the input if it cannot be decoded
    return;
};

1;

__END__

=pod

=head1 NAME

DDG::Goodie::HTMLEntities - Decode HTML Entities.

=head1 VERSION

version 0.090

=head1 AUTHORS

=over 4

=item *

Gabriel Weinberg <yegg@duckduckgo.com>

=item *

Torsten Raudssus <getty@duckduckgo.com>

=item *

Michael Smith <crazedpsyc@duckduckgo.com>

=item *

Hunter Lang <hunter@duckduckgo.com>

=back

=head1 COPYRIGHT AND LICENSE

This software is copyright (c) 2011 by DuckDuckGo, Inc. L<http://duckduckgo.com/>.

This is free software; you can redistribute it and/or modify it under
the same terms as the Perl 5 programming language system itself.

=cut
