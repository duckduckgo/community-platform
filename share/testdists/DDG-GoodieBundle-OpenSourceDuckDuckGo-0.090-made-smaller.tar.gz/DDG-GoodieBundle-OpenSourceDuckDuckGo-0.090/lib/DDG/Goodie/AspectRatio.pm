package DDG::Goodie::AspectRatio;
{
  $DDG::Goodie::AspectRatio::VERSION = '0.090';
}
# ABSTRACT: Calculates aspect ratio based on previously defined one

use DDG::Goodie;

triggers start => "aspect ratio";

zci is_cached => 1;
zci answer_type => "aspect_ratio";

primary_example_queries 'aspect ratio 4:3 640:?';
description 'complete the missing value with a given ratio';
name 'AspectRatio';
code_url 'https://github.com/duckduckgo/zeroclickinfo-goodies/blob/master/lib/DDG/Goodie/AspectRatio.pm';
category 'calculations';
topics 'math';
attribution github => [ 'https://github.com/mrshu', 'mrshu' ],
            twitter => [ 'https://twitter.com/mr__shu', 'mr__shu' ];

handle remainder => sub {
    my $input = $_;
    my $result = 0;
    my $ratio = 0;

    if ($input =~ /^(\d+(?:\.\d+)?)\s*\:\s*(\d+(?:\.\d+)?)\s*(?:(?:(\?)\s*:\s*(\d+(?:\.\d+)?))|(?:(\d+(?:\.\d+)?)\s*:\s*(\?)))$/){
        $ratio = $1 / $2;

        if ($6 && $6 eq "?") {
            $result = $5 / $ratio;
            return "Aspect ratio: $5:$result ($1:$2)";
        } elsif ($3 && $3 eq "?") {
            $result = $4 * $ratio;
            return "Aspect ratio: $result:$4 ($1:$2)";
        }
    }
    return;
};

1;

__END__

=pod

=head1 NAME

DDG::Goodie::AspectRatio - Calculates aspect ratio based on previously defined one

=head1 VERSION

version 0.090

=head1 AUTHORS

=over 4

=item *

Gabriel Weinberg <yegg@duckduckgo.com>

=item *

Torsten Raudssus <getty@duckduckgo.com>

=item *

Michael Smith <crazedpsyc@duckduckgo.com>

=item *

Hunter Lang <hunter@duckduckgo.com>

=back

=head1 COPYRIGHT AND LICENSE

This software is copyright (c) 2011 by DuckDuckGo, Inc. L<http://duckduckgo.com/>.

This is free software; you can redistribute it and/or modify it under
the same terms as the Perl 5 programming language system itself.

=cut
