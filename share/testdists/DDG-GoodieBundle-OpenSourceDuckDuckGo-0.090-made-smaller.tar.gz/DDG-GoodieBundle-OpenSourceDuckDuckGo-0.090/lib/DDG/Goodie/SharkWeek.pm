package DDG::Goodie::SharkWeek;
{
  $DDG::Goodie::SharkWeek::VERSION = '0.090';
}

use DDG::Goodie;
use JSON;
use DateTime;

zci answer_type => 'schedule';

primary_example_queries 'shark week schedule';
secondary_example_queries 'shark week';
description 'see the schedule for shark week';
name 'Calculator';
code_url 'https://github.com/duckduckgo/zeroclickinfo-goodies/blob/master/lib/DDG/Goodie/Calculator.pm';
category 'entertainment';
topics 'entertainment';
attribution web => [ 'https://www.duckduckgo.com', 'DuckDuckGo' ],
    github => [ 'https://github.com/duckduckgo', 'duckduckgo' ],
    twitter => ['http://twitter.com/duckduckgo', 'duckduckgo' ];

triggers start => 'shark';
my $schedule = decode_json(scalar share('shark.json')->slurp);

handle query_lc => sub {
    return unless $_ =~ /^shark week(?: schedule|)$/;
    my $dt = DateTime->today();
    my $key = $dt->day_name.' '.$dt->month_name . ' '.$dt->day;
    my @episodes = @{$schedule->{$key}};
#    return scalar(@episodes);

    my $html = "<ul>";
    my $txt = "$key Schedule\n";
    foreach my $e (@episodes) {
	my $time = $e->{'time'};
	my $title = $e->{'title'};
	my $description = $e->{'description'};
	$html .= "<li>$time - $title</li>";
	$txt .= "$time | $title\n";
    }
    $html .= "</ul>";
    
    return $txt, html => $html, heading => "$key Schedule";
};

1;

__END__

=pod

=head1 NAME

DDG::Goodie::SharkWeek

=head1 VERSION

version 0.090

=head1 AUTHORS

=over 4

=item *

Gabriel Weinberg <yegg@duckduckgo.com>

=item *

Torsten Raudssus <getty@duckduckgo.com>

=item *

Michael Smith <crazedpsyc@duckduckgo.com>

=item *

Hunter Lang <hunter@duckduckgo.com>

=back

=head1 COPYRIGHT AND LICENSE

This software is copyright (c) 2011 by DuckDuckGo, Inc. L<http://duckduckgo.com/>.

This is free software; you can redistribute it and/or modify it under
the same terms as the Perl 5 programming language system itself.

=cut
