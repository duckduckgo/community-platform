package DDG::Goodie::Braille;
{
  $DDG::Goodie::Braille::VERSION = '0.090';
}

use DDG::Goodie;
use Convert::Braille;
use utf8;

triggers query_raw => qr/\p{Braille}|braille/i;

zci is_cached => 1;

handle query_raw => sub {
    s/translate to braille |( in)? braille$|^braille //;
    return join(" ", map {lc(brailleDotsToAscii($_))} split(/\x{2800}/, $_)) . ' (Braille)' if /\p{Braille}/;
    # the space used in this join is not a normal space, it's a braille unicode space (U+2800)
    return join("\x{2800}", map {brailleAsciiToUnicode(uc $_)} split(/\s/, $_)) . ' (Braille)' if $_;    
    return;
};

1;

__END__

=pod

=head1 NAME

DDG::Goodie::Braille

=head1 VERSION

version 0.090

=head1 AUTHORS

=over 4

=item *

Gabriel Weinberg <yegg@duckduckgo.com>

=item *

Torsten Raudssus <getty@duckduckgo.com>

=item *

Michael Smith <crazedpsyc@duckduckgo.com>

=item *

Hunter Lang <hunter@duckduckgo.com>

=back

=head1 COPYRIGHT AND LICENSE

This software is copyright (c) 2011 by DuckDuckGo, Inc. L<http://duckduckgo.com/>.

This is free software; you can redistribute it and/or modify it under
the same terms as the Perl 5 programming language system itself.

=cut
