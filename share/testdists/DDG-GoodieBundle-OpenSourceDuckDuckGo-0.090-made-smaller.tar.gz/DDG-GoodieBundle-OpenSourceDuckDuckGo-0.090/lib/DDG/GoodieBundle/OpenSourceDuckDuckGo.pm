package DDG::GoodieBundle::OpenSourceDuckDuckGo;
{
  $DDG::GoodieBundle::OpenSourceDuckDuckGo::VERSION = '0.090';
}
# ABSTRACT: The open source Goodie Bundle of DuckDuckGo

# This package is only a namespace/version holder

1;

__END__

=pod

=head1 NAME

DDG::GoodieBundle::OpenSourceDuckDuckGo - The open source Goodie Bundle of DuckDuckGo

=head1 VERSION

version 0.090

=head1 AUTHORS

=over 4

=item *

Gabriel Weinberg <yegg@duckduckgo.com>

=item *

Torsten Raudssus <getty@duckduckgo.com>

=item *

Michael Smith <crazedpsyc@duckduckgo.com>

=item *

Hunter Lang <hunter@duckduckgo.com>

=back

=head1 COPYRIGHT AND LICENSE

This software is copyright (c) 2011 by DuckDuckGo, Inc. L<http://duckduckgo.com/>.

This is free software; you can redistribute it and/or modify it under
the same terms as the Perl 5 programming language system itself.

=cut
