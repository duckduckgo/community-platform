package DDG::Fathead::CssRef;
{
  $DDG::Fathead::CssRef::VERSION = '0.001';
}

use DDG::Fathead;

primary_example_queries "text-align css";

secondary_example_queries
    "css background-color";

description "CSS reference";

name "CSSRef";

icon_url "/i/developer.mozilla.org.ico";

source "Mozilla Developer Network";

code_url "https://github.com/duckduckgo/zeroclickinfo-fathead/tree/master/css_ref";

topics "geek", "web_design";

category "reference";

attribution
    github => ['https://github.com/dhruvbird', 'dhruvbird'],
    twitter => ['https://twitter.com/dhruvbird', 'dhruvbird'],
    web => ['http://dhruvbird.com', 'Dhruv Matani'];

1;
