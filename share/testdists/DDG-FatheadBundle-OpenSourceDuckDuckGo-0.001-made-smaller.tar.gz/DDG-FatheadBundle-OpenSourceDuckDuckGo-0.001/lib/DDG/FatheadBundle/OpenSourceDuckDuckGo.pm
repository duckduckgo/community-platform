package DDG::FatheadBundle::OpenSourceDuckDuckGo;
{
  $DDG::FatheadBundle::OpenSourceDuckDuckGo::VERSION = '0.001';
}
# ABSTRACT: The open source Fathead Bundle of DuckDuckGo

# This package is only a namespace/version holder

1;
