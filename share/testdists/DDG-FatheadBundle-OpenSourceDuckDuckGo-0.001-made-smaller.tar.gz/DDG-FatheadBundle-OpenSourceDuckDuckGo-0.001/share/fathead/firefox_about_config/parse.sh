#!/bin/bash

/usr/bin/env python2 parse.py
