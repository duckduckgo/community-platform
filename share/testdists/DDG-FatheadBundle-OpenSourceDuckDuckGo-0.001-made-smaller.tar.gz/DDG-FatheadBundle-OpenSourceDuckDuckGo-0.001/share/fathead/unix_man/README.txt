UNIX man-page fathead plugin for DuckDuckGo.

Source: http://www.linuxcommand.org/

Dependencies: 
----------------
wget 
perl -- plugin was developed with perl 5.16 
