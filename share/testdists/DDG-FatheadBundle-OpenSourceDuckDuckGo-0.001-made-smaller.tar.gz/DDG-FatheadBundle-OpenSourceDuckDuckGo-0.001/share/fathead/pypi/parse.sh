#!/bin/bash
ruby parse.rb > output.txt