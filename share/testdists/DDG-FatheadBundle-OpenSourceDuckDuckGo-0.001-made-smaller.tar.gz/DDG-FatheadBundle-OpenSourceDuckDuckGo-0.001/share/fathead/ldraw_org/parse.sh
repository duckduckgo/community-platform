#!/bin/bash
ruby parse.rb download/ldraw_org_unofficial_part_list.html > output.txt
