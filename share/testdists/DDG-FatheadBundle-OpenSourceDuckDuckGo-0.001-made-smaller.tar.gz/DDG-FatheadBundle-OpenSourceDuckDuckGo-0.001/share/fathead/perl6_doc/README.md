Perl 6 documentation fetcher and parser for DuckDuckGo

# Dependencies

* wget
* Perl v5.10
* CPAN modules:
  * `strictures`
  * `HTML::Entities`
  * `HTML::Parser`
  * `URI::Escape`
