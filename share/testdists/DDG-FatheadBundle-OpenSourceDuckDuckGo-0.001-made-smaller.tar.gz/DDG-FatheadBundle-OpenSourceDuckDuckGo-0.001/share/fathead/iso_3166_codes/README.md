Required packages:

[lxml](http://pypi.python.org/pypi/lxml/2.2.8)
[unidecode](http://pypi.python.org/pypi/Unidecode/0.04.9)
