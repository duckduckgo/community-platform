mkdir download
wget -O - -i data.url > download/raw.data

