#!/bin/bash
python parse.py
