#!/bin/bash

wget -q -P download -N 'https://www.archlinux.org/packages/?limit=all'
