#!/bin/bash
mkdir -p download
wget ftp://ftp.rfc-editor.org/in-notes/rfc-index.xml -O download/rfc-index.xml

