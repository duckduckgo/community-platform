#!/bin/bash
mkdir -p download
git clone https://git.gitorious.org/xmpp/xmpp.git download
