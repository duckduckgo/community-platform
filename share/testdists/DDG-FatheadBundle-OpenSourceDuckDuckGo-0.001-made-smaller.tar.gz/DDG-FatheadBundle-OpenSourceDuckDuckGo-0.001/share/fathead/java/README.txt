This is not 100% correct for the FatHead project but was used to generate
the sources for http://searchco.de/ which were shared with DDG. I belive
the TSV format used here is the basis for that project though so it should be
pretty close.

Dependancy is BeautifulSoup for Python. http://www.crummy.com/software/BeautifulSoup/

Note that the fetch might not work correctly. This is due to Oracle requiring
you to accept terms and conditions.
