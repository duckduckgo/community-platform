#!/bin/bash
go run parse.go -wikiinput="download/data" -output="output.txt"
