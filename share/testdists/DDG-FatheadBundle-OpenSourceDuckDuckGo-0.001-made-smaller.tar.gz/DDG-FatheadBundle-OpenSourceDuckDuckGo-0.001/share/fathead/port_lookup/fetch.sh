#!/bin/bash
mkdir -p download
wget "http://en.wikipedia.org/wiki/List_of_TCP_and_UDP_port_numbers" -O download/raw.dat
