HTML Referencing plugin for DuckDuckGo

Dependencies:
Python 2.7
BeautifulSoup 4 (pip install beautifulsoup4)

github.com/lucassmagal =D
