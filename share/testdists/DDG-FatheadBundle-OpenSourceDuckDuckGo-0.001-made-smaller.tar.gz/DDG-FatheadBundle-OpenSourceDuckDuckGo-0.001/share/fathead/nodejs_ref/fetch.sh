#!/bin/bash

mkdir -p download
wget -O ./download/all.html http://nodejs.org/api/all.html
