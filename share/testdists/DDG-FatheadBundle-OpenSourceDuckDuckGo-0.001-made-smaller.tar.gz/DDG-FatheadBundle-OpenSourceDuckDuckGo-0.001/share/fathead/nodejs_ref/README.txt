Dependencies

cd /usr/ports/www/node && make && make install
