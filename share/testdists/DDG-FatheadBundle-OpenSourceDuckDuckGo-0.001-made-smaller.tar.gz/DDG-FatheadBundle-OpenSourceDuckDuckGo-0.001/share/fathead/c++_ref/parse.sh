#!/bin/bash
node parse.js
