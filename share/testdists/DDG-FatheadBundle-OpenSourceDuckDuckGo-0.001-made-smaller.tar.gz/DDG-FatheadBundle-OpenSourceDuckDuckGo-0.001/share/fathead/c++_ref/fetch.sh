mkdir -p download
cd download
wget -np -nc -r -l 2 -I /reference/ http://www.cplusplus.com/reference/
