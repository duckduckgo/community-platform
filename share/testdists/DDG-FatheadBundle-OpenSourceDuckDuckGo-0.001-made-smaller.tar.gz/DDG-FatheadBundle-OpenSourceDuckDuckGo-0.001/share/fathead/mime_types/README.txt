MIME types plugin for DDG
Dependancies:

Python
To install in Ubuntu 12.04(Precise)
sudo apt-get install python
