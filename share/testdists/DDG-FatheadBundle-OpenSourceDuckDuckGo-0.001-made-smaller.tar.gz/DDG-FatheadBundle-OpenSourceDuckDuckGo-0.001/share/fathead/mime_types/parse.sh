#!/bin/bash
./parse.py
