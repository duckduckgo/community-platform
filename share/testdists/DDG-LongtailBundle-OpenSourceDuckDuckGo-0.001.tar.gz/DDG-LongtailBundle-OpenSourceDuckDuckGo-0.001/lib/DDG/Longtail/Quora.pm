package DDG::Longtail::Quora;
{
  $DDG::Longtail::Quora::VERSION = '0.001';
}

use DDG::Longtail;

name 'Quora';
description 'Quora';
source "Quora";
icon_url "/i/quora.com.ico";
topics 'trivia';
category 'q/a';
primary_example_queries '';
secondary_example_queries '', '';
code_url 'https://github.com/duckduckgo/zeroclickinfo-longtail/blob/master/lib/DDG/Longtail/Quora/';

1;
