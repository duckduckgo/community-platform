package DDG::LongtailBundle::OpenSourceDuckDuckGo;
{
  $DDG::LongtailBundle::OpenSourceDuckDuckGo::VERSION = '0.001';
}
# ABSTRACT: The open source Longtail Bundle of DuckDuckGo

# This package is only a namespace/version holder

1;
