The scraper can be used to scrape data off downloaded web-pages.

It is currently used to extract lyrics from downloaded web-pages.

You can plug in a parser of your choice for parsing web pages from
different sources and use the existing directory walking and output
logic.

The output bit is also pluggable via modules. Currently, 2 modules,
one for sqlite3 output and one for raw file output are provided.
