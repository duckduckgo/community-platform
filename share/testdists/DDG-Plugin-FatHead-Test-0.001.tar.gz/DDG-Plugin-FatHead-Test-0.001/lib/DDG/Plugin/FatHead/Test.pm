use strict;
use warnings;
package DDG::Plugin::FatHead::Test;
BEGIN {
  $DDG::Plugin::FatHead::Test::AUTHORITY = 'cpan:GETTY';
}
{
  $DDG::Plugin::FatHead::Test::VERSION = '0.001';
}
# ABSTRACT: What are you testing?

1;


__END__
=pod

=head1 NAME

DDG::Plugin::FatHead::Test - What are you testing?

=head1 VERSION

version 0.001

=head1 SYNOPSIS

    $here->isa(Piece::Of::Code);
    print <<"END";
    This indented block will not be scanned for formatting
    codes or directives, and spacing will be preserved.
    END

=head1 DESCRIPTION

Here's some normal text.  It includes text that is
B<bolded>, I<italicized> and C<$code>-formatted.

=head2 An Example List

=over 4

=item * This is a bulleted list.

=item * Here's another item.

=back

=head1 SEE ALSO

L<perlpod>, L<perldoc>, L<Pod::Parser>.

=cut

=head1 AUTHOR

Torsten Raudssus <torsten@raudssus.de>

=head1 COPYRIGHT AND LICENSE

This software is copyright (c) 2012 by Torsten Raudssus.

This is free software; you can redistribute it and/or modify it under
the same terms as the Perl 5 programming language system itself.

=cut

