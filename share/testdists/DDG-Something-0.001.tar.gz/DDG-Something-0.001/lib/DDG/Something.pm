use strict;
use warnings;
package DDG::Something;
BEGIN {
  $DDG::Something::AUTHORITY = 'cpan:GETTY';
}
{
  $DDG::Something::VERSION = '0.001';
}
# ABSTRACT: Something to test

1;


__END__
=pod

=head1 NAME

DDG::Something - Something to test

=head1 VERSION

version 0.001

=head1 SYNOPSIS

    $here->isa(Piece::Of::Code);
    print <<"END";
    This indented block will not be scanned for formatting
    codes or directives, and spacing will be preserved.
    END

=head1 DESCRIPTION

Here's some normal text.  It includes text that is
B<bolded>, I<italicized> and C<$code>-formatted.

=head2 An Example List

=over 4

=item * This is a bulleted list.

=item * Here's another item.

=back

=for html <img src="Example.png" align="right" alt="Figure 1." />
<p>
    Here's some embedded HTML.  In this block I can 
    include images, apply <span style="color: green">
    styles</span>, or do anything else I can do with
    HTML.  pod parsers that aren't outputting HTML will
    completely ignore it.
</p>

=head1 SEE ALSO

L<perlpod>, L<perldoc>, L<Pod::Parser>.

=cut

=head1 AUTHOR

Torsten Raudssus <torsten@raudssus.de>

=head1 COPYRIGHT AND LICENSE

This software is copyright (c) 2012 by Torsten Raudssus.

This is free software; you can redistribute it and/or modify it under
the same terms as the Perl 5 programming language system itself.

=cut

