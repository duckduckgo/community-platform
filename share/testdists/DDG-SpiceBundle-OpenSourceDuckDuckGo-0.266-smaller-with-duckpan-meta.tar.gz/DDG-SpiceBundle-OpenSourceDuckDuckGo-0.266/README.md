# DuckDuckHack Spice Instant Answers

This repository contains all the Spice instant answers. If you are developing a Spice instant answer you will need to fork this repository.

**If you would like to contribute to DuckDuckHack, please start by reading the [DuckDuckHack Documentationn](https://dukgo.com/duckduckhack/ddh-intro).**

------

### Spice Instant Answer Example
![quixey example](https://s3.amazonaws.com/ddg-assets/docs/spice_example.png)
