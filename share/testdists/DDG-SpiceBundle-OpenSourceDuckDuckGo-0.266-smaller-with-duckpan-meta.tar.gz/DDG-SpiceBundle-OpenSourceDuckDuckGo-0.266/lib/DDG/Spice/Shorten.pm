package DDG::Spice::Shorten;
{
  $DDG::Spice::Shorten::VERSION = '0.266';
}
# ABSTRACT: Return a shortened version of a URL using the bitly API.

use DDG::Spice;

primary_example_queries "shorten http://www.duckduckgo.com/about.html";
secondary_example_queries "url shorten www.github.com/explore";
description "Shorten URLs using the is.gd API";
name "Shorten";
icon_url "/i/is.gd.ico";
source "Shorten";
code_url "https://github.com/duckduckgo/zeroclickinfo-spice/blob/master/lib/DDG/Spice/Shorten.pm";
topics "social";
category "computing_tools";
attribution github => ['https://github.com/danjarvis','Dan Jarvis'],
            twitter => ['http://twitter.com/danjarvis','danjarvis'];

spice to => 'http://is.gd/create.php?format=json&url=$1&callback={{callback}}';
triggers any => 'shorten', 'shorten url', 'short url', 'url shorten';

handle remainder => sub {
	my ($longUri) = shift;

    return $longUri if $longUri;
	return;
};

1;

__END__

=pod

=head1 NAME

DDG::Spice::Shorten - Return a shortened version of a URL using the bitly API.

=head1 VERSION

version 0.266

=head1 AUTHORS

=over 4

=item *

Gabriel Weinberg <yegg@duckduckgo.com>

=item *

Torsten Raudssus <getty@duckduckgo.com>

=back

=head1 COPYRIGHT AND LICENSE

This software is copyright (c) 2011 by DuckDuckGo, Inc. L<http://duckduckgo.com/>.

This is free software; you can redistribute it and/or modify it under
the same terms as the Perl 5 programming language system itself.

=cut
