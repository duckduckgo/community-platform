package DDG::Spice::Zanran;
{
  $DDG::Spice::Zanran::VERSION = '0.266';
}

use DDG::Spice;

name "Zanran";
primary_example_queries "oil production in saudi arabia", "agriculture contribution to gdp";
secondary_example_queries "construction injuries australia", "global mobile data usage";
category "facts";
topics "economy_and_finance", "special_interest", "trivia";
description "Data and Statistics";
icon_url "/i/www.zanran.com.ico";
code_url "https://github.com/duckduckgo/zeroclickinfo-spice/blob/master/lib/DDG/Spice/Zanran.pm";
source "Zanran";
attribution github => ["https://github.com/taw", "taw"],
	        twitter => ["https://twitter.com/t_a_w", "t_a_w"];

spice to => 'http://www.zanran.com/search/simple_json?callback={{callback}}&q=$1';

my @triggers = share('triggers.txt')->slurp;

triggers any => @triggers;

handle query_lc => sub {
  return $_ if $_;
};

1;

__END__

=pod

=head1 NAME

DDG::Spice::Zanran

=head1 VERSION

version 0.266

=head1 AUTHORS

=over 4

=item *

Gabriel Weinberg <yegg@duckduckgo.com>

=item *

Torsten Raudssus <getty@duckduckgo.com>

=back

=head1 COPYRIGHT AND LICENSE

This software is copyright (c) 2011 by DuckDuckGo, Inc. L<http://duckduckgo.com/>.

This is free software; you can redistribute it and/or modify it under
the same terms as the Perl 5 programming language system itself.

=cut
