package DDG::Spice::Translate::FromTo;
{
  $DDG::Spice::Translate::FromTo::VERSION = '0.266';
}

use DDG::Spice;
use Moo;

with('DDG::SpiceRole::Translate');

attribution github  => ['https://github.com/ghedo', 'ghedo'      ],
            web     => ['http://ghedini.me', 'Alessandro Ghedini'];

my $langs = 'arabic|ar|chinese|zh|czech|cz|english|en|french|fr|greek|gr|italian|it|japanese|ja|korean|ko|polish|pl|portuguese|pt|romanian|ro|spanish|es|turkish|tr';

spice to   => 'http://api.wordreference.com/0.8/{{ENV{DDG_SPICE_WORDREFERENCE_APIKEY}}}/json/$1/$2?callback={{callback}}';
spice from => '(.+)\/(.+)';

triggers start => "translate";

handle query_lc => sub {
    my $query = $_;

    $query =~ s/\s+/ /; #merge multiple spaces

    if($query =~ /^translate (\S+) from ($langs)(?: to ($langs))?$/) {
        my ($phrase, $from, $to) = ($1, $2, $3);

        $from = shorten_lang($from);
        $to = (defined $to) ? shorten_lang($to) : substr($lang->locale, 0, 2);

        my $dict = $from.$to;

        # Wordreference API only supports translations
        # to or from english
        return unless $dict =~ /en/;

        return ($dict, $phrase);
    }

    return;
};

1;

__END__

=pod

=head1 NAME

DDG::Spice::Translate::FromTo

=head1 VERSION

version 0.266

=head1 AUTHORS

=over 4

=item *

Gabriel Weinberg <yegg@duckduckgo.com>

=item *

Torsten Raudssus <getty@duckduckgo.com>

=back

=head1 COPYRIGHT AND LICENSE

This software is copyright (c) 2011 by DuckDuckGo, Inc. L<http://duckduckgo.com/>.

This is free software; you can redistribute it and/or modify it under
the same terms as the Perl 5 programming language system itself.

=cut
