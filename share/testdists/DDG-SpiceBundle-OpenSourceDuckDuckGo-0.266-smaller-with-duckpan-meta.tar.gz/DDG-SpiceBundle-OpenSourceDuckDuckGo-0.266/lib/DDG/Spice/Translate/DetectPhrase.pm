package DDG::Spice::Translate::DetectPhrase;
{
  $DDG::Spice::Translate::DetectPhrase::VERSION = '0.266';
}

use DDG::Spice;
use Moo;

with('DDG::SpiceRole::Translate');

attribution github  => ['https://github.com/ghedo', 'ghedo'      ],
            web     => ['http://ghedini.me', 'Alessandro Ghedini'];

my $langs = 'arabic|ar|chinese|zh|czech|cz|english|en|french|fr|greek|gr|italian|it|japanese|ja|korean|ko|polish|pl|portuguese|pt|romanian|ro|spanish|es|turkish|tr';

spice to   => 'http://ws.detectlanguage.com/0.2/detect?q=$1&key={{ENV{DDG_SPICE_DETECTLANGUAGE_APIKEY}}}';
spice from => '(.+)\/(.+)';
spice wrap_jsonp_callback => 1;

triggers start => "translate";

handle query_lc => sub {
    my $query = $_;
    my $to;

    $query =~ s/\s+/ /; #merge multiple spaces

    # Don't need to detect when "from" language is given
    return if ($query =~ (/from (?:$langs)/));

    if ($query =~ /^translate (.*?)(?: to ([a-z]+))?$/) {
        my ($phrase, $to )= ($1, $2);

        $to = (defined $to) ? shorten_lang($to) : substr($lang->locale, 0, 2);

        # Only use MyMemory for multi-word translation
        return unless ($phrase =~ /\w+\s+\w+/);

        return ($phrase, $to);
    }

    return;
};

1;

__END__

=pod

=head1 NAME

DDG::Spice::Translate::DetectPhrase

=head1 VERSION

version 0.266

=head1 AUTHORS

=over 4

=item *

Gabriel Weinberg <yegg@duckduckgo.com>

=item *

Torsten Raudssus <getty@duckduckgo.com>

=back

=head1 COPYRIGHT AND LICENSE

This software is copyright (c) 2011 by DuckDuckGo, Inc. L<http://duckduckgo.com/>.

This is free software; you can redistribute it and/or modify it under
the same terms as the Perl 5 programming language system itself.

=cut
