package DDG::Spice::LeakDB;
{
  $DDG::Spice::LeakDB::VERSION = '0.266';
}

use DDG::Spice;

name 'LeakDB';
description 'Get plaintext or hash of input';
source 'leakdb.abusix.com';
primary_example_queries 'leakdb 21232f297a57a5a743894a0e4a801fc3';
secondary_example_queries 'hashme admin';
category 'special';
topics 'geek', 'sysadmin', 'cryptography';
icon_url 'https://leakdb.abusix.com/images/favicon.ico';
code_url 'https://github.com/brutalhonesty/zeroclickinfo-spice/blob/master/lib/DDG/Spice/HashMe.pm';
attribution github => ['https://github.com/brutalhonesty', 'Adam Schodde'],
	twitter => ['https://twitter.com/listeninme', 'listeninme'],
	email => ['sparky1010[at]gmail.com', 'Adam Schodde'];
status 'enabled';

triggers startend => 'hashme', 'leakdb';
spice to => 'http://api.leakdb.abusix.com/?j=$1';
spice wrap_jsonp_callback => 1;

handle remainder_lc => sub{
    s/^(hashme|leakdb)\s+|\s+(hashme|leakdb)$//g;
	return $_ if $_ ne '';
	return;
};

1;

__END__

=pod

=head1 NAME

DDG::Spice::LeakDB

=head1 VERSION

version 0.266

=head1 AUTHORS

=over 4

=item *

Gabriel Weinberg <yegg@duckduckgo.com>

=item *

Torsten Raudssus <getty@duckduckgo.com>

=back

=head1 COPYRIGHT AND LICENSE

This software is copyright (c) 2011 by DuckDuckGo, Inc. L<http://duckduckgo.com/>.

This is free software; you can redistribute it and/or modify it under
the same terms as the Perl 5 programming language system itself.

=cut
