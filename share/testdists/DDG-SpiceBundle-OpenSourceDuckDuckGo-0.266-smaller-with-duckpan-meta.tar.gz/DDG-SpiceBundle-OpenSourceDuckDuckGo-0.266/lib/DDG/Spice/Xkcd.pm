package DDG::Spice::Xkcd;
{
  $DDG::Spice::Xkcd::VERSION = '0.266';
}

use DDG::Spice;

name "xkcd";
description "Get the latest xkcd comic";
source "xkcd";
primary_example_queries "xkcd";
secondary_example_queries "xkcd 102";
category "special";
topics "entertainment", "geek", "special_interest";
icon_url "/i/xkcd.com.ico";
code_url "https://github.com/duckduckgo/zeroclickinfo-spice/blob/master/lib/DDG/Spice/Xkcd.pm";
attribution github => ["https://github.com/sdball", "Stephen Ball"],
            twitter => ["https://twitter.com/StephenBallNC", "StephenBallNC"];

triggers startend => "xkcd";

spice to => 'http://xkcd.com/$1/info.0.json';
spice wrap_jsonp_callback => 1;

handle remainder => sub {

	if ($_ =~ /^(\d+|r(?:andom)?)$/) {
		return int rand 1122 if $1 =~ /r/;
		return $1;
	}

	return '' if $_ eq '';
	return;
};

1;

__END__

=pod

=head1 NAME

DDG::Spice::Xkcd

=head1 VERSION

version 0.266

=head1 AUTHORS

=over 4

=item *

Gabriel Weinberg <yegg@duckduckgo.com>

=item *

Torsten Raudssus <getty@duckduckgo.com>

=back

=head1 COPYRIGHT AND LICENSE

This software is copyright (c) 2011 by DuckDuckGo, Inc. L<http://duckduckgo.com/>.

This is free software; you can redistribute it and/or modify it under
the same terms as the Perl 5 programming language system itself.

=cut
