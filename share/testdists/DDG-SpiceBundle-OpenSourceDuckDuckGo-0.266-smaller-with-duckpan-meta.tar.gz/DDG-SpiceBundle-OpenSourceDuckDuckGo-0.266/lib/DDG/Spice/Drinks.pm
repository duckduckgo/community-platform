package DDG::Spice::Drinks;
{
  $DDG::Spice::Drinks::VERSION = '0.266';
}

use DDG::Spice;

primary_example_queries "how to mix a tom collins";
secondary_example_queries "mixing 007", "how to make a 1.21 gigawatts";
description "Bartending info";
name "Drinks";
source "Drink Project";
code_url "https://github.com/duckduckgo/zeroclickinfo-spice/blob/master/lib/DDG/Spice/Drinks.pm";
topics "food_and_drink";
category "entertainment";
attribution github => ['https://github.com/mutilator','mutilator'];

triggers any => "drink", "make", "mix", "recipe", "ingredients";
triggers start => "mixing", "making";

spice to => 'http://drinkproject.com/api/?type=json&name=$1&callback={{callback}}';


handle query_lc => sub {
    if (/^((((making|mixing)+|(how\sto\s(make|mix)+)+)+(\s(a|an|the)*)*)|(mixed\s+)*drink(\s+(recipe|mix))*)+\s+(.+)$/) {
            return $12 if $12;
    }
    if (/^(.+)\s+(drink|mixed)\s(drink|mix|recipe|ingredients)$/) {
            return $1 if $1;
    }
    return;
};

1;

__END__

=pod

=head1 NAME

DDG::Spice::Drinks

=head1 VERSION

version 0.266

=head1 AUTHORS

=over 4

=item *

Gabriel Weinberg <yegg@duckduckgo.com>

=item *

Torsten Raudssus <getty@duckduckgo.com>

=back

=head1 COPYRIGHT AND LICENSE

This software is copyright (c) 2011 by DuckDuckGo, Inc. L<http://duckduckgo.com/>.

This is free software; you can redistribute it and/or modify it under
the same terms as the Perl 5 programming language system itself.

=cut
