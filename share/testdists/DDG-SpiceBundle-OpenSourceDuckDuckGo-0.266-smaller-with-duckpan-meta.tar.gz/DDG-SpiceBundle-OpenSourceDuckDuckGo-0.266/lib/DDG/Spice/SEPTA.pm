package DDG::Spice::SEPTA;
{
  $DDG::Spice::SEPTA::VERSION = '0.266';
}

use DDG::Spice;

primary_example_queries "next train from Villanova to Paoli";
secondary_example_queries "train times to paoli from Villanova";
description "Lookup the next SEPTA train going your way";
name "SEPTA";
source "SEPTA";
code_url "https://github.com/duckduckgo/zeroclickinfo-spice/blob/master/lib/DDG/Spice/SEPTA.pm";
topics "everyday";
category "time_sensitive";
attribution web => [ 'https://www.duckduckgo.com', 'DuckDuckGo' ],
            github => [ 'https://github.com/duckduckgo', 'duckduckgo'],
            twitter => ['http://twitter.com/duckduckgo', 'duckduckgo'];

spice to => 'http://www3.septa.org/hackathon/NextToArrive/$1/$2/5/';

spice wrap_jsonp_callback => 1;

triggers any => "next train", "train times", "train schedule", "septa";

spice from => '(.*)/(.*)';

handle query_lc => sub {
    s/\s+septa|septa\s+//;
    /(?:next trains?|train times|train schedule)?(?: from| to)? (.+) (to|from) (.+)/;
    my $curr = join " ", map { ucfirst } split /\s+/, $1;
    my $dest = join " ", map { ucfirst } split /\s+/, $3;
    return ($2 eq 'to' ? ($curr, $dest) : ($dest, $curr));
};

1;

__END__

=pod

=head1 NAME

DDG::Spice::SEPTA

=head1 VERSION

version 0.266

=head1 AUTHORS

=over 4

=item *

Gabriel Weinberg <yegg@duckduckgo.com>

=item *

Torsten Raudssus <getty@duckduckgo.com>

=back

=head1 COPYRIGHT AND LICENSE

This software is copyright (c) 2011 by DuckDuckGo, Inc. L<http://duckduckgo.com/>.

This is free software; you can redistribute it and/or modify it under
the same terms as the Perl 5 programming language system itself.

=cut
