package DDG::Spice::Npm;
{
  $DDG::Spice::Npm::VERSION = '0.266';
}
# ABSTRACT: Returns package information from npm package manager's registry.

use DDG::Spice;

primary_example_queries "npm underscore";
description "Shows an NPM package";
name "NPM";
code_url "https://github.com/duckduckgo/zeroclickinfo-spice/blob/master/lib/DDG/Spice/Npm.pm";
icon_url "/i/npmjs.org.ico";
topics "sysadmin", "programming";
category "programming";
attribution github  => ['https://github.com/remixz', 'remixz'],
            twitter => ['https://twitter.com/zachbruggeman', 'zachbruggeman'];

spice to => 'http://registry.npmjs.org/$1/latest';
spice wrap_jsonp_callback => 1;

triggers startend => 'npm';

handle remainder => sub {
	return $_ if $_;
	return;
};

1;

__END__

=pod

=head1 NAME

DDG::Spice::Npm - Returns package information from npm package manager's registry.

=head1 VERSION

version 0.266

=head1 AUTHORS

=over 4

=item *

Gabriel Weinberg <yegg@duckduckgo.com>

=item *

Torsten Raudssus <getty@duckduckgo.com>

=back

=head1 COPYRIGHT AND LICENSE

This software is copyright (c) 2011 by DuckDuckGo, Inc. L<http://duckduckgo.com/>.

This is free software; you can redistribute it and/or modify it under
the same terms as the Perl 5 programming language system itself.

=cut
