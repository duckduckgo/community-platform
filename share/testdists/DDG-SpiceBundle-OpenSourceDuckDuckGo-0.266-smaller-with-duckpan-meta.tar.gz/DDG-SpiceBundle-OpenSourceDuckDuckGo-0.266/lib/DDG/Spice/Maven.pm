package DDG::Spice::Maven;
{
  $DDG::Spice::Maven::VERSION = '0.266';
}
# ABSTRACT: Search library in Maven Central Repository.

use DDG::Spice;

attribution github  => ['https://github.com/nicoulaj', 'nicoulaj'],
            twitter => ['http://twitter.com/nicoulaj', 'nicoulaj'];

triggers startend => "maven", "mvn";

spice to => 'http://search.maven.org/solrsearch/select?q=$1&rows=5&wt=json&callback={{callback}}';
spice wrap_jsonp_callback => 1;
spice proxy_cache_valid   => "418 1d";

handle remainder => sub {
    return $_;
};

1;

__END__

=pod

=head1 NAME

DDG::Spice::Maven - Search library in Maven Central Repository.

=head1 VERSION

version 0.266

=head1 AUTHORS

=over 4

=item *

Gabriel Weinberg <yegg@duckduckgo.com>

=item *

Torsten Raudssus <getty@duckduckgo.com>

=back

=head1 COPYRIGHT AND LICENSE

This software is copyright (c) 2011 by DuckDuckGo, Inc. L<http://duckduckgo.com/>.

This is free software; you can redistribute it and/or modify it under
the same terms as the Perl 5 programming language system itself.

=cut
