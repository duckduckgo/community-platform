package DDG::Spice::AlternativeTo;
{
  $DDG::Spice::AlternativeTo::VERSION = '0.266';
}

use DDG::Spice;

primary_example_queries "alternative to notepad";
secondary_example_queries "alternative to photoshop for mac", "free alternative to spotify for windows";
description "Find software alternatives";
name "AlternativeTo";
icon_url "/i/alternativeto.net.ico";
source "AlternativeTo";
code_url "https://github.com/duckduckgo/zeroclickinfo-spice/blob/master/lib/DDG/Spice/AlternativeTo.pm";
topics  "everyday", "programming";
category  "computing_tools";
attribution github => ['https://github.com/Getty','Torsten Raudssus'],
           twitter => ['https://twitter.com/raudssus','raudssus'];

triggers start => "free","opensource","commercial";
triggers any => "alternative","alternatives";

spice from => '([^/]+)/(.*?)/([^/]*)';
spice to => 'http://api.alternativeto.net/software/$1/?platform=$2&license=$3&count=12&callback={{callback}}';


my %alternatives = (
    'google' => 'googlecom',
    'photoshop' => 'adobe-photoshop',
    'yahoo' => 'yahoo-search',
    'bing' => 'bingcom',
    'mac-os-x' => 'mac-os'
);

handle query_lc => sub {
    if (/^(?:(free|open\ssource|commercial))?\s*(?:alternative(?:s|)?\s*?(?:to|for)\s*?)(\b(?!for\b).*?\b)(?:\s*?for\s(.*))?$/) {
        my $license = $1 || "";
        my $prog = $2 || "";
        my $platform = $3 || "";

        $license =~ s/\s+//;

        $prog =~ s/\s+$//g;
        $prog =~ s/^\s+//g;
        $prog =~ s/\s+/-/g;
        $prog = $alternatives{$prog} if exists $alternatives{$prog};

        if($platform) {
            return $prog, $platform, $license;
        }
        return $prog, "all", $license;
    }
    return;
};

1;

__END__

=pod

=head1 NAME

DDG::Spice::AlternativeTo

=head1 VERSION

version 0.266

=head1 AUTHORS

=over 4

=item *

Gabriel Weinberg <yegg@duckduckgo.com>

=item *

Torsten Raudssus <getty@duckduckgo.com>

=back

=head1 COPYRIGHT AND LICENSE

This software is copyright (c) 2011 by DuckDuckGo, Inc. L<http://duckduckgo.com/>.

This is free software; you can redistribute it and/or modify it under
the same terms as the Perl 5 programming language system itself.

=cut
