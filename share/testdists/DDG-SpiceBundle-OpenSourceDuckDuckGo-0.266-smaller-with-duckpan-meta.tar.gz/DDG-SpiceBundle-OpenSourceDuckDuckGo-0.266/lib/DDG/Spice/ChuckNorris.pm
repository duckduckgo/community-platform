package DDG::Spice::ChuckNorris;
{
  $DDG::Spice::ChuckNorris::VERSION = '0.266';
}

use DDG::Spice;

primary_example_queries "chuck norris facts";
secondary_example_queries "chuck norris jokes";
description "Chuck Norris facts";
name "ChuckNorris";
source "Chuck Norris Database";
code_url "https://github.com/duckduckgo/zeroclickinfo-spice/blob/master/lib/DDG/Spice/ChuckNorris.pm";
topics "special_interest";
category "random";
attribution github => ['https://github.com/mr-mayank-gupta','Mayank Gupta'],
           twitter => ['http://twitter.com/iammayankg','iammayankg'];

spice proxy_cache_valid  => "418 1d";
spice is_unsafe => 1;
triggers start => 'chuck norris fact','chuck norris facts','chuck norris joke','chuck norris jokes';
spice to => 'http://api.icndb.com/jokes/random?escape=javascript&callback={{callback}}';
handle remainder => sub {
	return @_ ;
};
1;

__END__

=pod

=head1 NAME

DDG::Spice::ChuckNorris

=head1 VERSION

version 0.266

=head1 AUTHORS

=over 4

=item *

Gabriel Weinberg <yegg@duckduckgo.com>

=item *

Torsten Raudssus <getty@duckduckgo.com>

=back

=head1 COPYRIGHT AND LICENSE

This software is copyright (c) 2011 by DuckDuckGo, Inc. L<http://duckduckgo.com/>.

This is free software; you can redistribute it and/or modify it under
the same terms as the Perl 5 programming language system itself.

=cut
