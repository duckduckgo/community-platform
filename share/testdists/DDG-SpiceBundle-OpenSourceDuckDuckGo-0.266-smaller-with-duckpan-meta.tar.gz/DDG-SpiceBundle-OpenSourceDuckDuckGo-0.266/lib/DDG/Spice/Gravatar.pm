package DDG::Spice::Gravatar;
{
  $DDG::Spice::Gravatar::VERSION = '0.266';
}
# ABSTRACT: Shows gravatar of a given e-mail.

use DDG::Spice;
use Digest::MD5 qw(md5_hex);

primary_example_queries 'gravatar gravatar@duckduckgo.com';
secondary_example_queries 'gravatar duckduckhack';
description "Gravatar profile";
name "Gravatar";
code_url "https://github.com/duckduckgo/zeroclickinfo-spice/blob/master/lib/DDG/Spice/Gravatar.pm";
topics "special_interest", "social";
category "ids";
attribution github => ['https://github.com/adman','Adman'],
            twitter => ['http://twitter.com/adman_X','adman_X'];

triggers startend => "gravatar", "avatar of", "gravatar of";

spice to => 'http://en.gravatar.com/$1.json?callback={{callback}}';

handle remainder => sub {
    #Remove whitespace.
    s/^\s+|\s+$//;
    if($_ =~ /@/) {
        my $email_hash = md5_hex(lc $_);
        return $email_hash if $email_hash;
    } elsif($_) {
        return $_;
    }
    return;
};

1;

__END__

=pod

=head1 NAME

DDG::Spice::Gravatar - Shows gravatar of a given e-mail.

=head1 VERSION

version 0.266

=head1 AUTHORS

=over 4

=item *

Gabriel Weinberg <yegg@duckduckgo.com>

=item *

Torsten Raudssus <getty@duckduckgo.com>

=back

=head1 COPYRIGHT AND LICENSE

This software is copyright (c) 2011 by DuckDuckGo, Inc. L<http://duckduckgo.com/>.

This is free software; you can redistribute it and/or modify it under
the same terms as the Perl 5 programming language system itself.

=cut
