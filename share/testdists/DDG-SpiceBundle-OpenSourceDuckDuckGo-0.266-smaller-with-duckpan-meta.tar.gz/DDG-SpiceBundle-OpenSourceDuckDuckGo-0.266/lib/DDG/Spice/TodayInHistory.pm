package DDG::Spice::TodayInHistory;
{
  $DDG::Spice::TodayInHistory::VERSION = '0.266';
}

use DDG::Spice;

name 'Today In History';
description 'this day in history';
source 'History.com';
primary_example_queries 'xkcd';
secondary_example_queries 'xkcd 102';
category 'facts';
topics 'everyday', 'special_interest';
icon_url 'http://www.history.com/favicon.ico';
code_url 'https://github.com/duckduckgo/zeroclickinfo-spice/blob/master/lib/DDG/Spice/TodayInHistory.pm';
attribution web => [ 'https://www.duckduckgo.com', 'DuckDuckGo' ],
            github => [ 'https://github.com/duckduckgo', 'duckduckgo'],
            twitter => ['http://twitter.com/duckduckgo', 'duckduckgo'];

triggers startend => (
    'today in history',
    'todays in history',
    'this day in history',
);

spice to => 'http://www.history.com/this-day-in-history/rss';

spice wrap_string_callback => 1;

handle remainder => sub {
	return '' if $_ eq '';
	return;
};

1;

__END__

=pod

=head1 NAME

DDG::Spice::TodayInHistory

=head1 VERSION

version 0.266

=head1 AUTHORS

=over 4

=item *

Gabriel Weinberg <yegg@duckduckgo.com>

=item *

Torsten Raudssus <getty@duckduckgo.com>

=back

=head1 COPYRIGHT AND LICENSE

This software is copyright (c) 2011 by DuckDuckGo, Inc. L<http://duckduckgo.com/>.

This is free software; you can redistribute it and/or modify it under
the same terms as the Perl 5 programming language system itself.

=cut
