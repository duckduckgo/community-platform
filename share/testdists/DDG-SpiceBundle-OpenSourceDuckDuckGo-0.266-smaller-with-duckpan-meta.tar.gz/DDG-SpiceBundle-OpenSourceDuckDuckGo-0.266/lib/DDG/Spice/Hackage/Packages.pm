package DDG::Spice::Hackage::Packages;
{
  $DDG::Spice::Hackage::Packages::VERSION = '0.266';
}
# ABSTRACT: Search for information about Hackage packages

use DDG::Spice;

primary_example_queries "hackage containers";
description "Haskell packages";
name "Hackage";
code_url "https://github.com/duckduckgo/zeroclickinfo-spice/blob/master/lib/DDG/Spice/Hackage/Packages.pm";
topics "programming";
category "programming";
attribution github => ["https://github.com/nomeata", "Joachim Breitner"],
            web => ["http://www.joachim-breitner.de", "Joachim Breitner"],
            email => ['mail@joachim-breitner.de', "Joachim Breitner"];

triggers any => "hackage", "haskell";
spice to => 'http://typeful.net/~tbot/hackage/latest-package-versions.json';

spice wrap_jsonp_callback => 1;

handle remainder => sub {
    return $_ if $_;
    return;
};

1;

__END__

=pod

=head1 NAME

DDG::Spice::Hackage::Packages - Search for information about Hackage packages

=head1 VERSION

version 0.266

=head1 AUTHORS

=over 4

=item *

Gabriel Weinberg <yegg@duckduckgo.com>

=item *

Torsten Raudssus <getty@duckduckgo.com>

=back

=head1 COPYRIGHT AND LICENSE

This software is copyright (c) 2011 by DuckDuckGo, Inc. L<http://duckduckgo.com/>.

This is free software; you can redistribute it and/or modify it under
the same terms as the Perl 5 programming language system itself.

=cut
