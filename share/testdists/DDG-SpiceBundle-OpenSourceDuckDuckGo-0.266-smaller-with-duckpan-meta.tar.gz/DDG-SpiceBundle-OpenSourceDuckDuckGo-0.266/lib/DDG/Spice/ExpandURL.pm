package DDG::Spice::ExpandURL;
{
  $DDG::Spice::ExpandURL::VERSION = '0.266';
}
# ABSTRACT: Gives expanded url of the query

use DDG::Spice;

primary_example_queries "http://bit.ly/a", "expand bit.ly/lolcatz";
description "Expand shortened URLs using LongURL.org";
name "ExpandURL";
icon_url "/i/longurl.org.ico";
source "LongURL";
code_url "https://github.com/duckduckgo/zeroclickinfo-spice/blob/master/lib/DDG/Spice/ExpandURL.pm";
topics "social";
category "computing_tools";
attribution github => ['https://github.com/adman','Adman'],
           twitter => ['http://twitter.com/adman_X','adman_X'];

triggers start => "http", "https", "expand", "expandurl", "unshorten";

spice to => 'http://api.longurl.org/v2/expand?url=$1&format=json&callback={{callback}}';

handle query => sub {

    my $query = $_;
    $query =~ s/https?:\/\///gi;
    return unless $query =~ /.+\..+/;

    if ($query =~ qr/(?:expand|unshorten)(?:\s*url)?\s+([^\s]+)/i){
        return $1;

    } elsif ($query =~ qr/^((?=[0123467abcdefghijklmnopqrstuvwxyz])(?:1(?:link\.in|url\.com)|2(?:\.gp|big\.at|tu\.us)|3(?:\.ly|07\.to)|4(?:ms\.me|sq\.com|url\.cc)|a(?:\.(?:gg|nf)|d(?:\.vu|f\.ly|jix\.com)|l(?:l\.fuse|t)url\.com|r(?:\.gy|st\.ch)|a\.cx|bcurl\.net|(?:fx|zc)\.cc|mzn\.to|tu\.ca)|b(?:2(?:3\.ru|l\.me)|i(?:nged\.it|t\.ly|zj\.us)|(?:acn|loat)\.me|cool\.bz|(?:ravo|sa)\.ly|udurl\.com)|c(?:h(?:ilp\.it|zb\.gr)|l(?:\.l[ky]|i(?:c(?:cami\.info|kthru\.ca)|\.gs)|ck\.ru|op\.in)|o(?:nta\.cc|rt\.as|t\.ag)|anurl\.com|rks\.me|(?:tvr|utt)\.us)|d(?:i(?:g(?:bi)?g\.com|sq\.us)|l(?:d\.bz|vr\.it)|o(?:\.my|iop\.com|pen\.us)|ai\.ly|b\.tt|ecenturl\.com|fl8\.me)|e(?:asyur(?:i\.com|l\.net)|(?:epurl|weri)\.com)|f(?:a(?:\.by|v\.me)|b(?:share)?\.me|f(?:\.im|f\.to)|ir(?:sturl\.(?:de|net)|e\.to)|l(?:ic\.kr|(?:q\.u|y2\.w)s)|u(?:seurl\.com|zzy\.to)|w(?:d4\.me|ib\.net)|on\.gs|reak\.to)|g(?:o(?:\.(?:(?:9nl|ign)\.com|usa\.gov)|o\.gl|shrink\.com)|\.ro\.lt|izmo\.do|l\.am|url\.es)|h(?:u(?:rl\.(?:me|ws)|ff\.to|lu\.com)|ex\.io|(?:iderefer|sblinks)\.com|mm\.ph|ref\.in|txt\.it)|i(?:canhaz\.com|(?:dek\.ne|x\.l)t|lix\.in|s\.gd|ts\.my)|j(?:\.mp|ijr\.com)|k(?:l(?:\.am|ck\.me)|orta\.nu|runchd\.com)|l(?:i(?:nkb(?:ee\.com|un\.ch)|ip\.to|fehac\.kr|ltext\.com|url\.cn)|n(?:\-s\.(?:net|ru)|k(?:\.(?:gd|ms)|d\.in|url\.com))|9k\.net|at\.ms|ru\.jp|t\.tl|url\.no)|m(?:a(?:cte\.ch|sh\.to)|e(?:\.lt|lt\.li|rky\.de)|i(?:n(?:iurl\.com|url\.fr)|gre\.me)|o(?:by\.to|ourl\.com)|y(?:loc\.me|url\.in)|ke\.me|rte\.ch)|n(?:b(?:c\.co|lo\.gs)|ot(?:\.my|long\.com)|\.pr|n\.nf|(?:sfw|xy)\.in|utshellurl\.com|yti\.ms)|o(?:m(?:\.ly|f\.gd|oikane\.net)|n(?:\.(?:cnn\.com|mktw\.net)|forb\.es)|\-x\.fr|c1\.us|rz\.se|w\.ly)|p(?:o(?:liti\.co|st\.ly)|(?:ing\.f|(?:titurl|ub\.vitrue)\.co)m|li\.gs|nt\.me|p\.gg|rofile\.to)|q(?:lnk\.net|te\.me|u\.tc|y\.fi)|r(?:e(?:a(?:d(?:\.bi|this\.ca)|llytinyurl\.com)|dir(?:\.ec|ects\.ca|x\.com)|twt\.me)|i(?:\.ms|ckroll\.it|z\.gd)|u(?:\.ly|byurl\.com|rl\.org)|\.im|b6\.me|t\.nu|ww\.tw)|s(?:a(?:fe\.mn|meurl\.com)|h(?:o(?:r(?:t(?:\.(?:ie|to)|links\.co\.uk|url\.com)|l\.com)|ut\.to|w\.my)|r(?:ink(?:ify|r)\.com|t(?:\.(?:fr|st)|en\.com)|unkin\.com)|ar\.es|ink\.de)|m(?:allr\.com|(?:sh\.|url\.na)me)|n(?:ip(?:r|url)\.com|(?:\.i|url\.co)m)|p(?:2\.ro|edr\.com)|r(?:nk\.net|s\.li)|u(?:rl\.(?:co\.uk|hu)|\.pr)|4c\.in|(?:7y|dut)\.us|(?:elnd|(?:im|tart)url)\.com|late\.me)|t(?:\.(?:c[no]|lh\.com)|gr\.(?:me|ph)|i(?:n(?:y(?:\.(?:cc|ly|pl)|ur(?:i\.ca|l\.com)|link\.in)|iuri\.com)|ghturl\.com)|n(?:ij\.org|w\.to|y\.com)|o(?:\.(?:ly)?|(?:goto|tc|ysr)\.us)|r(?:\.im|a\.kz|unc\.it)|w(?:i(?:t(?:terurl\.(?:net|org)|clicks\.com|url\.de)|rl\.at)|url\.(?:cc|nl)|hub\.com)|[al]\.gd|(?:bd|pm)\.ly|crn\.ch|k\.|mi\.me)|u(?:\.(?:mavrev\.com|nu)|r(?:l(?:\.(?:az|co\.uk|ie)|b(?:org|rief)\.com|c(?:over|ut)\.com|s(?:\.i|horteningservicefortwitter\.co)m|(?:360\.m|enco\.d|x\.i)e|4\.eu|i\.nl|zen\.com)|1\.ca)|s(?:at\.l|e\.m)y|76\.org|b0\.cc|lu\.lu|pdating\.me)|v(?:b\.ly|(?:gn|l)\.am|m\.lc)|w(?:ap(?:o\.st|url\.co\.uk)|(?:55\.d|p\.m)e|ipi\.es)|x(?:r(?:l\.(?:in|us)|\.com)|url\.(?:es|jp)|\.vu)|y(?:e(?:\.pe|p\.it)|(?:\.a)?hoo\.it|(?:atuc|frog|iyd|uarel)\.com|outu\.be)|z(?:i(?:\.m[au]|pmyurl\.com)|u(?:d\.me|rl\.ws)|z(?:\.gd|ang\.kr)|0p\.de)|0rz\.tw|6url\.com|7\.ly)\/.*)$/i) {
        return $1;

    } else {
        return;
    }
};

1;

__END__

=pod

=head1 NAME

DDG::Spice::ExpandURL - Gives expanded url of the query

=head1 VERSION

version 0.266

=head1 AUTHORS

=over 4

=item *

Gabriel Weinberg <yegg@duckduckgo.com>

=item *

Torsten Raudssus <getty@duckduckgo.com>

=back

=head1 COPYRIGHT AND LICENSE

This software is copyright (c) 2011 by DuckDuckGo, Inc. L<http://duckduckgo.com/>.

This is free software; you can redistribute it and/or modify it under
the same terms as the Perl 5 programming language system itself.

=cut
