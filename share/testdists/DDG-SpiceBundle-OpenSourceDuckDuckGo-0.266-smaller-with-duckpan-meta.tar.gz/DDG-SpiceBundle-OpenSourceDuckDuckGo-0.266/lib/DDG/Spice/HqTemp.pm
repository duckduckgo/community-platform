package DDG::Spice::HqTemp;
{
  $DDG::Spice::HqTemp::VERSION = '0.266';
}

use DDG::Spice;

spice to => 'YOUR_URL_HERE';
spice proxy_cache_valid => "418 1d";
spice wrap_jsonp_callback => 1;
triggers startend => "temperature at duckduckgo";

handle remainder => sub {
    return $_;
};

1;

__END__

=pod

=head1 NAME

DDG::Spice::HqTemp

=head1 VERSION

version 0.266

=head1 AUTHORS

=over 4

=item *

Gabriel Weinberg <yegg@duckduckgo.com>

=item *

Torsten Raudssus <getty@duckduckgo.com>

=back

=head1 COPYRIGHT AND LICENSE

This software is copyright (c) 2011 by DuckDuckGo, Inc. L<http://duckduckgo.com/>.

This is free software; you can redistribute it and/or modify it under
the same terms as the Perl 5 programming language system itself.

=cut
