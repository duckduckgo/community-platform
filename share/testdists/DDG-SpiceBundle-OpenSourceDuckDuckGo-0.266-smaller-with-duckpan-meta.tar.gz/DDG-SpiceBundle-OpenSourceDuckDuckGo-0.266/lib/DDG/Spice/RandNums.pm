package DDG::Spice::RandNums;
{
  $DDG::Spice::RandNums::VERSION = '0.266';
}
# ABSTRACT: Get a sequence of random numbers

use DDG::Spice;

primary_example_queries "random numbers 10 11";
description "Displays a random number";
name "RandNums";
code_url "https://github.com/duckduckgo/zeroclickinfo-spice/blob/master/lib/DDG/Spice/RandNums.pm";
topics "special_interest", "everyday", "math";
category "random";
attribution github  => ['https://github.com/ghedo', 'ghedo'],
            web => ['http://ghedini.me', 'Alessandro Ghedini'];

spice to   => 'http://www.random.org/integers/?num=10&min=$1&max=$2&col=10&base=10&format=plain&rnd=new';
spice from => '(\-?[0-9]+)\/(\-?[0-9]+)';

spice proxy_cache_valid => "418 1d";
spice wrap_string_callback => 1;

triggers query_lc => qr/^(?:rand|random) (?:numbers?|nums?)(?: (\-?[0-9]+)\s*(?:-|to)?\s*(\-?[0-9]+))?$/;

handle matches => sub {
    my ($min, $max) = @_;

	$min = 1   unless defined $min;
	$max = 100 unless defined $max;

	$min = -1000000000 if $min < -1000000000;
	$max =  1000000000 if $max >  1000000000;

	return $max, $min if $min >= $max;
    return $min, $max;
};

1;

__END__

=pod

=head1 NAME

DDG::Spice::RandNums - Get a sequence of random numbers

=head1 VERSION

version 0.266

=head1 AUTHORS

=over 4

=item *

Gabriel Weinberg <yegg@duckduckgo.com>

=item *

Torsten Raudssus <getty@duckduckgo.com>

=back

=head1 COPYRIGHT AND LICENSE

This software is copyright (c) 2011 by DuckDuckGo, Inc. L<http://duckduckgo.com/>.

This is free software; you can redistribute it and/or modify it under
the same terms as the Perl 5 programming language system itself.

=cut
