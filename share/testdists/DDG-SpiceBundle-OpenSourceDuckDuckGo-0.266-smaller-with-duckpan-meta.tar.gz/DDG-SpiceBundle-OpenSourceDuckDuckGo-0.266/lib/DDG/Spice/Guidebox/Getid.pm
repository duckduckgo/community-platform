package DDG::Spice::Guidebox::Getid;
{
  $DDG::Spice::Guidebox::Getid::VERSION = '0.266';
}

use DDG::Spice;

primary_example_queries "guidebox Castle";
description "Search for full free episodes of all your favorite TV shows (USA only)";
name "Guidebox";
code_url "https://github.com/duckduckgo/zeroclickinfo-spice/blob/master/lib/DDG/Spice/Guidebox/Getid.pm";
icon_url "/i/www.guidebox.com.ico";
topics "everyday", "entertainment", "social";
category "entertainment";
attribution github => ['https://github.com/adman','Adman'],
            twitter => ['http://twitter.com/adman_X','adman_X'];

triggers startend => "guidebox";
triggers start => "watch", "stream", "full episodes of", "full free episodes of", "free episodes of", "episodes of", "where to watch";
triggers any => "full episodes", "watch free", "full free episodes", "free episodes", "episodes", "recent episodes";

spice to => 'http://api-public.guidebox.com/v1.3/json/{{ENV{DDG_SPICE_GUIDEBOX_APIKEY}}}/search/title/$1';

spice wrap_jsonp_callback => 1;

handle remainder => sub {
    if ($loc->country_name eq "United States" || $loc->country_name eq "Canada"){
        
        my $show = '';
        
        if ($_ =~ qr/^([\w\s]+)\s*?(?:episodes?)? online$/ ){
            $show = $1; 
        } elsif ($_ =~ qr/^episodes? of ([\w\s]+)\s*?(?:\s*online)?$/){
            $show = $1;
        } elsif ($_ =~ qr/^([\w\s]+)\s*?episodes?$/){
            $show = $1;
        } elsif ($_ =~ qr/^([\w\s]+)\s*?series$/){
            $show = $1;
        } elsif ($_ =~ qr/^([\w\s]+)\s*?tv series$/){
            $show = $1;
        } else {
            $show = $_;
        }
        return $show if $show;
    }
    return;
};

1;

__END__

=pod

=head1 NAME

DDG::Spice::Guidebox::Getid

=head1 VERSION

version 0.266

=head1 AUTHORS

=over 4

=item *

Gabriel Weinberg <yegg@duckduckgo.com>

=item *

Torsten Raudssus <getty@duckduckgo.com>

=back

=head1 COPYRIGHT AND LICENSE

This software is copyright (c) 2011 by DuckDuckGo, Inc. L<http://duckduckgo.com/>.

This is free software; you can redistribute it and/or modify it under
the same terms as the Perl 5 programming language system itself.

=cut
