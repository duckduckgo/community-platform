package DDG::Spice::Rhymes;
{
  $DDG::Spice::Rhymes::VERSION = '0.266';
}

use DDG::Spice;

name "Rhymes";
description "find rhyming words";
source "RhymeBrain";
primary_example_queries "what rhymes with duck";
secondary_example_queries "go rhymes with", "words that rhyme with smile";
category "language";
topics "everyday", "music", "words_and_games";
code_url "https://github.com/duckduckgo/zeroclickinfo-spice/blob/master/lib/DDG/Spice/Rhymes.pm";
icon_url "/i/rhymebrain.com.ico";
attribution web => ['http://dylansserver.com','Dylan Lloyd'],
            email => ['dylan@dylansserver.com','Dylan Lloyd'];

triggers any => "rhyme", "rhymes";

spice to => 'http://rhymebrain.com/talk?function=getRhymes&word=$1&jsonp={{callback}}';

spice proxy_cache_valid => "418 1d";

handle remainder_lc => sub {
    /^
    (?:(?:what|words|that?)\s+){0,2}
    (?:(?:with|for)\s+)?
    ([a-zA-Z]+)
    (?:\s+with)?\??
    $/x;
    return $1 if defined $1;
    return;
};

1;

__END__

=pod

=head1 NAME

DDG::Spice::Rhymes

=head1 VERSION

version 0.266

=head1 AUTHORS

=over 4

=item *

Gabriel Weinberg <yegg@duckduckgo.com>

=item *

Torsten Raudssus <getty@duckduckgo.com>

=back

=head1 COPYRIGHT AND LICENSE

This software is copyright (c) 2011 by DuckDuckGo, Inc. L<http://duckduckgo.com/>.

This is free software; you can redistribute it and/or modify it under
the same terms as the Perl 5 programming language system itself.

=cut
