package DDG::Spice::InTheaters;
{
  $DDG::Spice::InTheaters::VERSION = '0.266';
}
# ABSTRACT: Show movies from Rotten Tomatoes.

use DDG::Spice;

primary_example_queries "movies";
secondary_example_queries "movies in theaters", "currently in theaters", "i want to watch a movie";
description "Current movies from Rotten Tomatoes";
name "InTheaters";
code_url "https://github.com/duckduckgo/zeroclickinfo-spice/blob/master/lib/DDG/Spice/InTheaters.pm";
icon_url "/i/www.rottentomatoes.com.ico";
topics "entertainment";
category "entertainment";
attribution github => ['https://github.com/jagtalon','jagtalon'],
            twitter => ['http://twitter.com/juantalon','juantalon'];

my $rating = '(?:g\s*|pg\s*|r\s*)?';
triggers any => 'movie', 'movies', 'theaters', 'theatres', 'showing', 'something', 'watch', 'opening', 'see';
spice from => '(.*?)/(.*)';
spice to => 'http://api.rottentomatoes.com/api/public/v1.0/lists/movies/$1.json?country=$2&apikey={{ENV{DDG_SPICE_ROTTEN_APIKEY}}}&callback={{callback}}&page_limit=12&limit=12';

# Uses $loc so needs to not cache back end.
spice is_cached => 0;

spice proxy_cache_valid => "418 1d";

my %movies = (
	'movies now showing' => 1,
	'what can i watch?' => 1,
	'movies opening' => 0,
	'movies opening soon' => 0,
	'watch a movie' => 1,
	'opening soon in theaters' => 0,
	'opening soon in theatres' => 0,
	'opening movies' => 0,
	'r movies opening' => 0,
	'pg movies opening' => 0,
	'pg-13 movies opening' => 0,
	'g movies opening' => 0,
	'see an r movie' => 1,
	'see a pg movie' => 1,
	'see a pg-13 movie' => 1,
	'see a g movie' =>1,
	'r movies opening soon' => 0,
	'pg movies opening soon' => 0,
	'pg-13 movies opening soon' => 0,
	'g movies opening soon' => 0,
	'i need to watch a movie' => 1,
	'i deserve to watch a movie' => 1,
	'i want to watch a movie' => 1,
	'i want to watch an r movie' => 1,
	'i want to watch a pg movie' => 1,
	'i want to watch a pg-13 movie' =>1,
	'i want to watch something' => 1,
	'watch something' => 1,
	'need to watch a movie' => 1,
	'need to watch an r movie' => 1,
	'need to watch a pg movie' => 1,
	'need to watch a pg-13 movie' => 1,
	'need to watch a g movie' => 1,
	'watch an r movie' => 1,
	'watch a pg movie' => 1,
	'watch an pg-13 movie' => 1,
	'watch a g movie' => 1,
	'theaters' => 0,
	'theatres' => 0,
	'movies' => 1,
	'r movies' => 1,
	'pg movies' => 1,
	'pg-13 movies' => 1,
	'g movies' => 1,
	'movies in theaters' => 1,
	'r movies in theaters' => 1,
	'pg movies in theaters' => 1,
	'pg-13 movies in theaters' => 1,
	'g movies in theaters' => 1,
	'movies currently in theaters' => 1,
	'movies currently in theatres' => 1,
	'currently in theaters' => 1,
	'currently in theatres' => 1,
	);

handle query_lc => sub {
	return unless exists $movies{$_};
	if($movies{$_}) {
		return "in_theaters", $loc->country_code;
	} else {
		return "opening", $loc->country_code;
	}
};
1;

__END__

=pod

=head1 NAME

DDG::Spice::InTheaters - Show movies from Rotten Tomatoes.

=head1 VERSION

version 0.266

=head1 AUTHORS

=over 4

=item *

Gabriel Weinberg <yegg@duckduckgo.com>

=item *

Torsten Raudssus <getty@duckduckgo.com>

=back

=head1 COPYRIGHT AND LICENSE

This software is copyright (c) 2011 by DuckDuckGo, Inc. L<http://duckduckgo.com/>.

This is free software; you can redistribute it and/or modify it under
the same terms as the Perl 5 programming language system itself.

=cut
