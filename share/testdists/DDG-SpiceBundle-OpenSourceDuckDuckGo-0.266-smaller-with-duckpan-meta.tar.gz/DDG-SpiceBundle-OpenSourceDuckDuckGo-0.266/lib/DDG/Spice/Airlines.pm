package DDG::Spice::Airlines;
{
  $DDG::Spice::Airlines::VERSION = '0.266';
}

use DDG::Spice;

primary_example_queries "AA 102";
secondary_example_queries "Delta 3684";
description "Flight information";
name "Flight Info";
icon_url "/i/flightaware.com.ico";
source "FlightAware";
code_url "https://github.com/duckduckgo/zeroclickinfo-spice/blob/master/lib/DDG/Spice/Airlines.pm";
topics "economy_and_finance", "travel", "everyday";
category "time_sensitive";
attribution web => [ 'https://www.duckduckgo.com', 'DuckDuckGo' ],
            github => [ 'https://github.com/duckduckgo', 'duckduckgo'],
            twitter => ['http://twitter.com/duckduckgo', 'duckduckgo'];

spice to => 'https://duckduckgo.com/flights.js?airline=$1&flightno=$2&callback={{callback}}';
spice from => '(.*?)/(.*)';

triggers query_lc => qr/^(\d+)\s*(.*?)(?:[ ]air.*?)?$|^(.*?)(?:[ ]air.*?)?\s*(\d+)$/;

# Get the list of airlines and strip out the words.
my %airlines = ();
my @airlines_lines = share('airlines.txt')->slurp;
foreach my $line (@airlines_lines) {
  chomp($line);
  my @line = split(/,/, $line);

  $line[1] =~ s/\s+air.*$//i;

  #American (Airlines <- regex removed) => AA
  $airlines{lc $line[1]} = $line[0];
  #AA => AA
  $airlines{lc $line[0]} = $line[0];
}

# Get the list of elements because an airline name can be an element.
my %elements = ();
my @elements_lines = share('symbols.txt')->slurp;
foreach my $line (@elements_lines) {
    chomp $line;
    my @line = split(/,/, $line);
    $elements{$line[0]} = 1;
    $elements{$line[1]} = 1;
}

handle query_lc => sub {
    my $query = $_;

    sub checkAirlines {
        my ($airline, $flightno, $original) = @_;

        # Check if we found something and if it's not an element.
        if($airline && !exists $elements{$airline}) {
            return $airline, $flightno;
        } else {
            return;
        }
    }

    # 102 AA

    if($query =~ /^(\d+)\s*(.*?)(?:[ ]air.*?)?$/) {
        return checkAirlines($airlines{$2}, $1, $2);
    # AA 102
    } elsif($query =~ /^(.*?)(?:[ ]air.*?)?\s*(\d+)$/) {
        return checkAirlines($airlines{$1}, $2, $1);
    }
    return;
};

1;

__END__

=pod

=head1 NAME

DDG::Spice::Airlines

=head1 VERSION

version 0.266

=head1 AUTHORS

=over 4

=item *

Gabriel Weinberg <yegg@duckduckgo.com>

=item *

Torsten Raudssus <getty@duckduckgo.com>

=back

=head1 COPYRIGHT AND LICENSE

This software is copyright (c) 2011 by DuckDuckGo, Inc. L<http://duckduckgo.com/>.

This is free software; you can redistribute it and/or modify it under
the same terms as the Perl 5 programming language system itself.

=cut
