package DDG::Spice::Automeme;
{
  $DDG::Spice::Automeme::VERSION = '0.266';
}

# ABSTRACT: DuckDuckGo + Automeme.net = profound nonsense

use DDG::Spice;

primary_example_queries "random meme";
secondary_example_queries "automeme", "meme generator";
description "Generate a random meme";
name "Automeme";
icon_url "/i/blog.automeme.net.ico";
source "Automeme";
code_url "https://github.com/duckduckgo/zeroclickinfo-spice/blob/master/lib/DDG/Spice/Automeme.pm";
topics "special_interest";
category "random";
attribution github => ['https://github.com/mjgardner','Mark Gardner'];

spice to => 'http://api.automeme.net/html.json?lines=1$1&callback={{callback}}';
spice wrap_jsonp_callback => 1;
spice proxy_cache_valid   => "418 1d";
spice is_unsafe => 1;

triggers any => "automeme", "random meme", "meme generator";

handle remainder => sub {

   # If you liked Automeme before it was cool, use the vocab=hipster parameter
   # for some unique hipster words.
    /hipster/i and return '&vocab=hipster';
    return q{};
};

1;

__END__

=pod

=head1 NAME

DDG::Spice::Automeme - DuckDuckGo + Automeme.net = profound nonsense

=head1 VERSION

version 0.266

=head1 AUTHORS

=over 4

=item *

Gabriel Weinberg <yegg@duckduckgo.com>

=item *

Torsten Raudssus <getty@duckduckgo.com>

=back

=head1 COPYRIGHT AND LICENSE

This software is copyright (c) 2011 by DuckDuckGo, Inc. L<http://duckduckgo.com/>.

This is free software; you can redistribute it and/or modify it under
the same terms as the Perl 5 programming language system itself.

=cut
