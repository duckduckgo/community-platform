use strict;
use warnings;
package My::Sample::Distribution;
BEGIN {
  $My::Sample::Distribution::AUTHORITY = 'cpan:GETTY';
}
{
  $My::Sample::Distribution::VERSION = '0.003';
}
# ABSTRACT: It's a sample distribution

1;

__END__
=pod

=head1 NAME

My::Sample::Distribution - It's a sample distribution

=head1 VERSION

version 0.003

=head1 AUTHORS

=over 4

=item *

Torsten Raudssus <torsten@raudssus.de>

=item *

Another Author <someone@somewhere>

=back

=head1 COPYRIGHT AND LICENSE

This software is copyright (c) 2012 by Torsten Raudssus.

This is free software; you can redistribute it and/or modify it under
the same terms as the Perl 5 programming language system itself.

=cut

