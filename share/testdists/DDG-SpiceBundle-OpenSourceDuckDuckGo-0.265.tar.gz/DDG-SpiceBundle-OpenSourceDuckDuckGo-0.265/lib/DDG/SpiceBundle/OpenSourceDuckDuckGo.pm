package DDG::SpiceBundle::OpenSourceDuckDuckGo;
{
  $DDG::SpiceBundle::OpenSourceDuckDuckGo::VERSION = '0.265';
}
# ABSTRACT: The open source Spice Bundle of DuckDuckGo

# This package is only a namespace/version holder

1;

__END__
=pod

=head1 NAME

DDG::SpiceBundle::OpenSourceDuckDuckGo - The open source Spice Bundle of DuckDuckGo

=head1 VERSION

version 0.265

=head1 AUTHORS

=over 4

=item *

Gabriel Weinberg <yegg@duckduckgo.com>

=item *

Torsten Raudssus <getty@duckduckgo.com>

=back

=head1 COPYRIGHT AND LICENSE

This software is copyright (c) 2011 by DuckDuckGo, Inc. L<http://duckduckgo.com/>.

This is free software; you can redistribute it and/or modify it under
the same terms as the Perl 5 programming language system itself.

=cut

