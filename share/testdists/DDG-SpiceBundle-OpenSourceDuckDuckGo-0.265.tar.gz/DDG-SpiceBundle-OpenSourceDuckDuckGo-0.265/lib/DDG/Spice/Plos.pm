package DDG::Spice::Plos;
{
  $DDG::Spice::Plos::VERSION = '0.265';
}

use DDG::Spice;

name 'PLOS Search';
description 'Search research articles of PLOS journals';
primary_example_queries 'plos dinosaurs', 'plos echinoderm evolution';
secondary_example_queries 'plos dinosaurs title:metabolism';
source 'PLOS';
category 'special';
topics 'science';
icon_url 'http://www.plosone.org/images/favicon.ico';
code_url 'https://github.com/duckduckgo/zeroclickinfo-spice/blob/master/lib/DDG/Spice/Plos.pm';
attribution twitter => 'nelas',
			github => ['nelas', 'Bruno C. Vellutini'],
			web => ['http://organelas.com/', 'organelas.com'];

triggers startend => 'plos';

spice to => 'http://api.plos.org/search?q=$1&rows=10&wt=json'
            . '&fl=id,title_display,author_display,journal,volume,issue,publication_date'
            . '&api_key={{ENV{DDG_SPICE_PLOS_APIKEY}}}';
spice wrap_jsonp_callback => 1;

handle remainder => sub {
    return $_ if $_;
    return;
};

1;

__END__
=pod

=head1 NAME

DDG::Spice::Plos

=head1 VERSION

version 0.265

=head1 AUTHORS

=over 4

=item *

Gabriel Weinberg <yegg@duckduckgo.com>

=item *

Torsten Raudssus <getty@duckduckgo.com>

=back

=head1 COPYRIGHT AND LICENSE

This software is copyright (c) 2011 by DuckDuckGo, Inc. L<http://duckduckgo.com/>.

This is free software; you can redistribute it and/or modify it under
the same terms as the Perl 5 programming language system itself.

=cut

