package DDG::Spice::OpenSNP;
{
  $DDG::Spice::OpenSNP::VERSION = '0.265';
}

use DDG::Spice;

primary_example_queries 'rs7903146';
description 'Single Nucleotide Polymorphisms';
name 'OpenSNP';
code_url 'https://github.com/duckduckgo/zeroclickinfo-spice/blob/master/lib/DDG/Spice/OpenSNP.pm';
topics 'science';
category 'reference';
attribution github => ['https://github.com/drsnuggles','Philipp Bayer'],
            twitter => ['https://twitter.com/PhilippBayer', 'PhilippBayer'];

spice to => 'http://opensnp.org/snps/json/annotation/$1.json';
spice proxy_cache_valid  => "5m";
spice wrap_jsonp_callback => 1;

triggers query_lc  => qr/(^rs[0-9]+)$/;

handle query_nowhitespace => sub {
    return $_ if $_;
    return;
};

1;

__END__
=pod

=head1 NAME

DDG::Spice::OpenSNP

=head1 VERSION

version 0.265

=head1 AUTHORS

=over 4

=item *

Gabriel Weinberg <yegg@duckduckgo.com>

=item *

Torsten Raudssus <getty@duckduckgo.com>

=back

=head1 COPYRIGHT AND LICENSE

This software is copyright (c) 2011 by DuckDuckGo, Inc. L<http://duckduckgo.com/>.

This is free software; you can redistribute it and/or modify it under
the same terms as the Perl 5 programming language system itself.

=cut

