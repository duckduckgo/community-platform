package DDG::Spice::Betterific;
{
  $DDG::Spice::Betterific::VERSION = '0.265';
}

use DDG::Spice;

name "betterific";
description "Search Betterific for smart, innovative ideas to improve products and services.";
source "betterific";
primary_example_queries "betterific Arby's";
secondary_example_queries "betterif General Electric";
category "special";
topics "entertainment", "everyday", "social", "special_interest";
code_url "https://github.com/bradcater/zeroclickinfo-spice/blob/master/lib/DDG/Spice/Betterific.pm";
attribution github => ["https://github.com/bradcater", "Brad Cater"],
            twitter => ["https://twitter.com/bradcater", "bradcater"];

triggers startend => "betterif", "better if", "betterific";

spice to => 'http://betterific.com/api/search/all?q=$1&page=1&per_page=2';

spice wrap_jsonp_callback => 1;

handle remainder => sub {
  # If the query isn't blank, then use it for the API query.
  return $_ if length($_) > 0;

	return '' if $_ eq '';
	return;
};

1;

__END__
=pod

=head1 NAME

DDG::Spice::Betterific

=head1 VERSION

version 0.265

=head1 AUTHORS

=over 4

=item *

Gabriel Weinberg <yegg@duckduckgo.com>

=item *

Torsten Raudssus <getty@duckduckgo.com>

=back

=head1 COPYRIGHT AND LICENSE

This software is copyright (c) 2011 by DuckDuckGo, Inc. L<http://duckduckgo.com/>.

This is free software; you can redistribute it and/or modify it under
the same terms as the Perl 5 programming language system itself.

=cut

