package DDG::Spice::RubyGems;
{
  $DDG::Spice::RubyGems::VERSION = '0.265';
}

use DDG::Spice;

name 'RubyGems';
description 'Returns a list of matching ruby packages in rubygems.org';
primary_example_queries 'rubygems cucumber';
topics 'programming';
category 'programming';
attribution github => ['https://github.com/koosha--', 'koosha--'],
            twitter => ['https://github.com/_koosha_', '_koosha_'];

triggers startend => 'ruby', 'gem', 'gems', 'rubygem', 'rubygems';
spice to => 'http://rubygems.org/api/v1/search.json?query=$1&callback={{callback}}';
spice wrap_jsonp_callback => 1;

handle remainder => sub {
    s/^\s+//;
    s/\s+$//;
    return $_ if length $_;
    return;
};

1;

__END__
=pod

=head1 NAME

DDG::Spice::RubyGems

=head1 VERSION

version 0.265

=head1 AUTHORS

=over 4

=item *

Gabriel Weinberg <yegg@duckduckgo.com>

=item *

Torsten Raudssus <getty@duckduckgo.com>

=back

=head1 COPYRIGHT AND LICENSE

This software is copyright (c) 2011 by DuckDuckGo, Inc. L<http://duckduckgo.com/>.

This is free software; you can redistribute it and/or modify it under
the same terms as the Perl 5 programming language system itself.

=cut

