package DDG::Spice::Video;
{
  $DDG::Spice::Video::VERSION = '0.265';
}

use DDG::Spice;

primary_example_queries "ted education video", "wong fu videos", "coffee videos";
description "Shows videos from around the web.";
name "Video";
code_url "https://github.com/duckduckgo/zeroclickinfo-spice/blob/master/lib/DDG/Spice/Video.pm";
topics "everyday", "entertainment";
category "entertainment";
attribution github => ["https://github.com/duckduckgo/", "DuckDuckGo"],
            twitter => ["https://twitter.com/duckduckgo", "duckduckgo"];


spice to => 'https://duckduckgo.com/v.js?q=$1&n=20&callback={{callback}}';
triggers startend => 'video', 'videos', 'youtube';

handle remainder => sub {
    return $_ if $_;
    return;
};

1;

__END__
=pod

=head1 NAME

DDG::Spice::Video

=head1 VERSION

version 0.265

=head1 AUTHORS

=over 4

=item *

Gabriel Weinberg <yegg@duckduckgo.com>

=item *

Torsten Raudssus <getty@duckduckgo.com>

=back

=head1 COPYRIGHT AND LICENSE

This software is copyright (c) 2011 by DuckDuckGo, Inc. L<http://duckduckgo.com/>.

This is free software; you can redistribute it and/or modify it under
the same terms as the Perl 5 programming language system itself.

=cut

