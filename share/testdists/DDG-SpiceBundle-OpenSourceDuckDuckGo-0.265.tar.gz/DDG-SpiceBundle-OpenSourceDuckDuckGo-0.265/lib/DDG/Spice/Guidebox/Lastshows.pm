package DDG::Spice::Guidebox::Lastshows;
{
  $DDG::Spice::Guidebox::Lastshows::VERSION = '0.265';
}

use DDG::Spice;

triggers any => "///***never_trigger***///";

spice to => 'http://api-public.guidebox.com/v1.3/json/{{ENV{DDG_SPICE_GUIDEBOX_APIKEY}}}/$1/watch/all/20';

spice wrap_jsonp_callback => 1;

handle remainder => sub {
    
    # TODO
    # Detect if iOS/Android and change api call
    # ie. /best_available/ios/ or /best_available/android/
    return  $_ if $_;
    return;
};

1;

__END__
=pod

=head1 NAME

DDG::Spice::Guidebox::Lastshows

=head1 VERSION

version 0.265

=head1 AUTHORS

=over 4

=item *

Gabriel Weinberg <yegg@duckduckgo.com>

=item *

Torsten Raudssus <getty@duckduckgo.com>

=back

=head1 COPYRIGHT AND LICENSE

This software is copyright (c) 2011 by DuckDuckGo, Inc. L<http://duckduckgo.com/>.

This is free software; you can redistribute it and/or modify it under
the same terms as the Perl 5 programming language system itself.

=cut

