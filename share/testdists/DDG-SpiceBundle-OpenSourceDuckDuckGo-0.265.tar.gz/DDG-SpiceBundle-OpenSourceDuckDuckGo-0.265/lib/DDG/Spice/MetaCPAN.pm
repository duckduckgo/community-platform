package DDG::Spice::MetaCPAN;
{
  $DDG::Spice::MetaCPAN::VERSION = '0.265';
}
# ABSTRACT: Show a summary of the searched CPAN module.

use DDG::Spice;

primary_example_queries "metacpan WWW::DuckDuckGo";
description "Searches CPAN modules";
name "MetaCPAN";
code_url "https://github.com/duckduckgo/zeroclickinfo-spice/blob/master/lib/DDG/Spice/MetaCPAN.pm";
icon_url "/i/metacpan.org.ico";
topics "programming", "sysadmin";
category "programming";
attribution github  => ['https://github.com/ghedo', 'ghedo'],
            web => ['http://ghedini.me', 'Alessandro Ghedini'];

spice to   => 'http://api.metacpan.org/v0/module/$1?callback={{callback}}';

triggers startend => "cpan", "cpanm", "metacpan", "meta cpan";

handle remainder => sub {
    return $_ if $_;
    return;
};
1;

__END__
=pod

=head1 NAME

DDG::Spice::MetaCPAN - Show a summary of the searched CPAN module.

=head1 VERSION

version 0.265

=head1 AUTHORS

=over 4

=item *

Gabriel Weinberg <yegg@duckduckgo.com>

=item *

Torsten Raudssus <getty@duckduckgo.com>

=back

=head1 COPYRIGHT AND LICENSE

This software is copyright (c) 2011 by DuckDuckGo, Inc. L<http://duckduckgo.com/>.

This is free software; you can redistribute it and/or modify it under
the same terms as the Perl 5 programming language system itself.

=cut

