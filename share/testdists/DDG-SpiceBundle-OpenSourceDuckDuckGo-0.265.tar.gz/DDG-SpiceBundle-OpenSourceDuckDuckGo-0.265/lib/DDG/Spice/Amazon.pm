package DDG::Spice::Amazon;
{
  $DDG::Spice::Amazon::VERSION = '0.265';
}

use DDG::Spice;

spice to => 'https://duckduckgo.com/m.js?q=$1&cb=ddg_spice_amazon';

triggers start => '///***never trigger***///';

handle remainder => sub {
    return "$_" if $_;
};

1;


__END__
=pod

=head1 NAME

DDG::Spice::Amazon

=head1 VERSION

version 0.265

=head1 AUTHORS

=over 4

=item *

Gabriel Weinberg <yegg@duckduckgo.com>

=item *

Torsten Raudssus <getty@duckduckgo.com>

=back

=head1 COPYRIGHT AND LICENSE

This software is copyright (c) 2011 by DuckDuckGo, Inc. L<http://duckduckgo.com/>.

This is free software; you can redistribute it and/or modify it under
the same terms as the Perl 5 programming language system itself.

=cut

