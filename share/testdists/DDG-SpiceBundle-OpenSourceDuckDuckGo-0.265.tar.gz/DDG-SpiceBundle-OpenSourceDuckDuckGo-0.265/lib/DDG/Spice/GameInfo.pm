package DDG::Spice::GameInfo;
{
  $DDG::Spice::GameInfo::VERSION = '0.265';
}

use DDG::Spice;
primary_example_queries "homesick game";
description "See information about a game";
name "GameInfo";
icon_url "/i/thefreegamesdb.com/favicon.ico";
source "thefreegamesdb.com & thegamesdb.net";
topics "gaming";
category "reference";
attribution github => ['https://github.com/thomaspreece10','thomaspreece10'];

triggers startend => "game","games";
spice to => 'http://tfgdb.com/API/DuckDuckGo.php?Name=$1';
spice wrap_jsonp_callback => 1;

handle remainder => sub {
    return $_ if $_;
    return;
};


1;

__END__
=pod

=head1 NAME

DDG::Spice::GameInfo

=head1 VERSION

version 0.265

=head1 AUTHORS

=over 4

=item *

Gabriel Weinberg <yegg@duckduckgo.com>

=item *

Torsten Raudssus <getty@duckduckgo.com>

=back

=head1 COPYRIGHT AND LICENSE

This software is copyright (c) 2011 by DuckDuckGo, Inc. L<http://duckduckgo.com/>.

This is free software; you can redistribute it and/or modify it under
the same terms as the Perl 5 programming language system itself.

=cut

