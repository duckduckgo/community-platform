package DDG::Spice::Book;
{
  $DDG::Spice::Book::VERSION = '0.265';
}

use DDG::Spice;

primary_example_queries "book reviews moonwalking with einstein";
description "Shows critic rating and a sample review of a book from publications like NY Times, NPR, Guardian.";
name "iDreambooks";
code_url "https://github.com/duckduckgo/zeroclickinfo-spice/blob/master/lib/DDG/Spice/Book.pm";
category "reference";
topics "entertainment", "everyday";

spice to => 'http://idreambooks.com/api/books/reviews.json?api_key={{ENV{DDG_SPICE_BOOK_APIKEY}}}&bpq=10&q=$1';

triggers startend => "idreambooks", "book reviews", "book review";

spice wrap_jsonp_callback => 1;
spice is_cached => 1;

handle remainder => sub {
    return $_ if $_;
    return;
};

1;


__END__
=pod

=head1 NAME

DDG::Spice::Book

=head1 VERSION

version 0.265

=head1 AUTHORS

=over 4

=item *

Gabriel Weinberg <yegg@duckduckgo.com>

=item *

Torsten Raudssus <getty@duckduckgo.com>

=back

=head1 COPYRIGHT AND LICENSE

This software is copyright (c) 2011 by DuckDuckGo, Inc. L<http://duckduckgo.com/>.

This is free software; you can redistribute it and/or modify it under
the same terms as the Perl 5 programming language system itself.

=cut

