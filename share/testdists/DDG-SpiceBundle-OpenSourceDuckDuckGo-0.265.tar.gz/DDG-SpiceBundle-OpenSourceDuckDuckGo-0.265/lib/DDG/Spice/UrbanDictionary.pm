package DDG::Spice::UrbanDictionary;
{
  $DDG::Spice::UrbanDictionary::VERSION = '0.265';
}
# ABSTRACT: Give the Urban Dictionary definition of the search query.

use DDG::Spice;

primary_example_queries "urban dictionary ROTFL";
secondary_example_queries "ud OMG", "ud ASD";
description "Lookup UrbanDictionary definitions";
name "UrbanDictionary";
icon_url "/i/urbandictionary.com.ico";
source "UrbanDictionary";
code_url "https://github.com/duckduckgo/zeroclickinfo-spice/blob/master/lib/DDG/Spice/UrbanDictionary.pm";
topics "geek";
category "language";
attribution github => ['https://github.com/FiloSottile','FiloSottile'],
            web => ['http://pytux.it','Filippo Valsorda'],
            email => ['filippo.valsorda@gmail.com','Filippo Valsorda'];

spice is_unsafe => 1;

triggers startend => "ud", "urban", "urbandictionary", "urban dictionary";

spice to => 'http://api.urbandictionary.com/v0/define?term=$1&callback={{callback}}';

handle remainder => sub {
    my ($term) = @_;
    return $term if $term;
    return;
};

1;

__END__
=pod

=head1 NAME

DDG::Spice::UrbanDictionary - Give the Urban Dictionary definition of the search query.

=head1 VERSION

version 0.265

=head1 AUTHORS

=over 4

=item *

Gabriel Weinberg <yegg@duckduckgo.com>

=item *

Torsten Raudssus <getty@duckduckgo.com>

=back

=head1 COPYRIGHT AND LICENSE

This software is copyright (c) 2011 by DuckDuckGo, Inc. L<http://duckduckgo.com/>.

This is free software; you can redistribute it and/or modify it under
the same terms as the Perl 5 programming language system itself.

=cut

