package DDG::Spice::Smbc;
{
  $DDG::Spice::Smbc::VERSION = '0.265';
}

use DDG::Spice;

name 'smbc';
description 'Get the latest Saturday Morning Breakfast Cereal comic';
source 'smbc';
primary_example_queries 'smbc';
category 'special';
topics 'entertainment', 'geek', 'special_interest';
code_url 'https://github.com/duckduckgo/zeroclickinfo-spice/blob/master/lib/DDG/Spice/Smbc.pm';
attribution web => ['http://dylansserver.com','Dylan Lloyd'],
            email => ['dylan@dylansserver.com','Dylan Lloyd'];
status 'enabled';


triggers any => 'smbc', 'saturday morning breakfast cereal';

spice to => 'http://comics.signedzero.com/smbc/feed.json';
spice wrap_jsonp_callback => 1;

handle query_lc => sub {
    s/(today'?s )?(smbc|saturday morning breakfast cereal)( comic)?//g;
    return '' if $_ eq '';
    return;
};

1;

__END__
=pod

=head1 NAME

DDG::Spice::Smbc

=head1 VERSION

version 0.265

=head1 AUTHORS

=over 4

=item *

Gabriel Weinberg <yegg@duckduckgo.com>

=item *

Torsten Raudssus <getty@duckduckgo.com>

=back

=head1 COPYRIGHT AND LICENSE

This software is copyright (c) 2011 by DuckDuckGo, Inc. L<http://duckduckgo.com/>.

This is free software; you can redistribute it and/or modify it under
the same terms as the Perl 5 programming language system itself.

=cut

