package DDG::Spice::UserAgent;
{
  $DDG::Spice::UserAgent::VERSION = '0.265';
}

use DDG::Spice;

name "User Agent";
description "Returns user agent information";
primary_example_queries "useragent";
topics "programming", "sysadmin";
category "reference";
code_url "https://github.com/duckduckgo/zeroclickinfo-spice/blob/master/lib/DDG/Spice/UserAgent.pm";
attribution web => ['http://duckduckgo.com', 'DuckDuckGo'],
            twitter => ['http://twitter.com/duckduckgo', 'duckduckgo'];

triggers startend => "user agent", "useragent";

spice call_type => 'self';

handle query_lc => sub {
    return $_ eq 'user agent' ? call : ();
};

1;
__END__
=pod

=head1 NAME

DDG::Spice::UserAgent

=head1 VERSION

version 0.265

=head1 AUTHORS

=over 4

=item *

Gabriel Weinberg <yegg@duckduckgo.com>

=item *

Torsten Raudssus <getty@duckduckgo.com>

=back

=head1 COPYRIGHT AND LICENSE

This software is copyright (c) 2011 by DuckDuckGo, Inc. L<http://duckduckgo.com/>.

This is free software; you can redistribute it and/or modify it under
the same terms as the Perl 5 programming language system itself.

=cut

