package DDG::Spice::Bootic;
{
  $DDG::Spice::Bootic::VERSION = '0.265';
}
# ABSTRACT: Search for products on Bootic.

use DDG::Spice;

primary_example_queries "bootic watches";
secondary_example_queries "bootic irobot";
description "Search Bootic.";
name "Bootic";
icon_url "/i/www.bootic.com.ico";
source "Bootic";
code_url "https://github.com/duckduckgo/zeroclickinfo-spice/blob/master/lib/DDG/Spice/Bootic.pm";
category "entertainment";
topics "special_interest";
attribution github => ['https://github.com/sparky','sparky'];

triggers any => 'bootic';
spice to => 'http://www.bootic.com/cgi-bin/api/search/products?output=json&callback={{callback}}&pretty_name=1&limit=48&smart=1&q=$1';

handle remainder => sub {
	return $_ if $_;
	return;
};

1;

__END__
=pod

=head1 NAME

DDG::Spice::Bootic - Search for products on Bootic.

=head1 VERSION

version 0.265

=head1 AUTHORS

=over 4

=item *

Gabriel Weinberg <yegg@duckduckgo.com>

=item *

Torsten Raudssus <getty@duckduckgo.com>

=back

=head1 COPYRIGHT AND LICENSE

This software is copyright (c) 2011 by DuckDuckGo, Inc. L<http://duckduckgo.com/>.

This is free software; you can redistribute it and/or modify it under
the same terms as the Perl 5 programming language system itself.

=cut

