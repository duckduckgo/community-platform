package DDG::Spice::GithubJobs;
{
  $DDG::Spice::GithubJobs::VERSION = '0.265';
}
# ABSTRACT: Search for jobs on Github.

use DDG::Spice;

primary_example_queries "javascript jobs";
secondary_example_queries "perl jobs in san francisco";
description "Github jobs";
name "Github Jobs";
code_url "https://github.com/duckduckgo/zeroclickinfo-spice/blob/master/lib/DDG/Spice/GithubJobs.pm";
topics "programming", "special_interest";
category  "programming";
attribution github => ['https://github.com/jagtalon','jagtalon'],
            twitter => ['http://twitter.com/juantalon','juantalon'];

triggers any => "job", "jobs";

spice to => 'https://jobs.github.com/positions.json?description=$1&location=$2&callback={{callback}}';
spice from => '(.*?)-(.*)';

handle query_lc => sub {
    if (/(?:\s*(?:i\s+|we\s+)?(?:need|want|deserve|seek|get)\s+(?:an?\s+)?)?(?:(.+)\s+)(?:jobs?|work|employment|internship)(?:\s+(?:in\s+)?(.+))?$/i) {
        if($1 && $2) {
            return $1.'-'.$2;
        }
        if($1) {
            return $1.'-';
        }
        if($2) {
            return '-'.$2;
        }
    }
	return;
};

1;

__END__
=pod

=head1 NAME

DDG::Spice::GithubJobs - Search for jobs on Github.

=head1 VERSION

version 0.265

=head1 AUTHORS

=over 4

=item *

Gabriel Weinberg <yegg@duckduckgo.com>

=item *

Torsten Raudssus <getty@duckduckgo.com>

=back

=head1 COPYRIGHT AND LICENSE

This software is copyright (c) 2011 by DuckDuckGo, Inc. L<http://duckduckgo.com/>.

This is free software; you can redistribute it and/or modify it under
the same terms as the Perl 5 programming language system itself.

=cut

