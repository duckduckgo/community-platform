package DDG::Spice::Imdb;
{
  $DDG::Spice::Imdb::VERSION = '0.265';
}
# ABSTRACT: Give a summary of the movie from its IMDB page.

use DDG::Spice;

primary_example_queries "IMDb shawshank redemption";
description "Display movie information from IMDB";
name "Imdb";
code_url "https://github.com/duckduckgo/zeroclickinfo-spice/blob/master/lib/DDG/Spice/Imdb.pm";
icon_url "/i/www.imdb.com.ico";
topics "entertainment";
category "entertainment";
attribution github => ['https://github.com/viswanathgs','viswanathgs'];

triggers startend => "imdb";

spice to => 'http://www.imdbapi.com/?t=$1&callback={{callback}}';

handle remainder => sub {
    return $_ if $_;
    return;
};

1;

__END__
=pod

=head1 NAME

DDG::Spice::Imdb - Give a summary of the movie from its IMDB page.

=head1 VERSION

version 0.265

=head1 AUTHORS

=over 4

=item *

Gabriel Weinberg <yegg@duckduckgo.com>

=item *

Torsten Raudssus <getty@duckduckgo.com>

=back

=head1 COPYRIGHT AND LICENSE

This software is copyright (c) 2011 by DuckDuckGo, Inc. L<http://duckduckgo.com/>.

This is free software; you can redistribute it and/or modify it under
the same terms as the Perl 5 programming language system itself.

=cut

