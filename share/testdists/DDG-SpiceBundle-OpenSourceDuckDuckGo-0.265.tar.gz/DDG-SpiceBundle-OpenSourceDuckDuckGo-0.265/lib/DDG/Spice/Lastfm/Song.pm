package DDG::Spice::Lastfm::Song;
{
  $DDG::Spice::Lastfm::Song::VERSION = '0.265';
}
# ABSTRACT: Display song info.

use DDG::Spice;

primary_example_queries "Payphone song by Maroon 5";
description "Song information";
name "LastFM Song";
icon_url "/i/www.last.fm.ico";
source "Last.fm";
code_url "https://github.com/duckduckgo/zeroclickinfo-spice/blob/master/lib/DDG/Spice/Lastfm/Song.pm";
topics "entertainment", "music";
category "entertainment";
attribution github => ['https://github.com/jagtalon','Jag Talon'],
           twitter => ['http://twitter.com/juantalon','Jag Talon'];

spice to => 'http://ws.audioscrobbler.com/2.0/?format=json&method=track.getinfo&track=$1&artist=$2&autocorrect=1&api_key={{ENV{DDG_SPICE_LASTFM_APIKEY}}}&callback={{callback}}';
spice from => '(?:([^/]*)/([^/]*)|)';

triggers query_lc => qr/ ^
                         ([^\s]+(?:\s+[^\s]+)*)\s+
                         (?:tracks?|songs?|music)\s+
                         (?:by|from)\s+
                         ([^\s]+(?:\s+[^\s]+)*)
                         $|^
                         (?:listen(?:\s+to)?)\s+
                         ([^\s]+(?:\s+[^\s]+)*)\s+
                         (?:by|from)\s+
                         ([^\s]+(?:\s+[^\s]+)*)
                         $/x;


handle matches => sub {
    if($1 && $2) {
        return $1, $2;
    } elsif($3 && $4) {
    	return $3, $4;
    }
    return;
};

1;

__END__
=pod

=head1 NAME

DDG::Spice::Lastfm::Song - Display song info.

=head1 VERSION

version 0.265

=head1 AUTHORS

=over 4

=item *

Gabriel Weinberg <yegg@duckduckgo.com>

=item *

Torsten Raudssus <getty@duckduckgo.com>

=back

=head1 COPYRIGHT AND LICENSE

This software is copyright (c) 2011 by DuckDuckGo, Inc. L<http://duckduckgo.com/>.

This is free software; you can redistribute it and/or modify it under
the same terms as the Perl 5 programming language system itself.

=cut

