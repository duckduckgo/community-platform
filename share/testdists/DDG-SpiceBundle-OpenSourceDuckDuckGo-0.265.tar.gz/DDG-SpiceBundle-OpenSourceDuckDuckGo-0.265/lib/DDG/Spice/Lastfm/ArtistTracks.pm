package DDG::Spice::Lastfm::ArtistTracks;
{
  $DDG::Spice::Lastfm::ArtistTracks::VERSION = '0.265';
}
# ABSTRACT: Get the tracks of a musician.

use DDG::Spice;

primary_example_queries "songs by she & him";
secondary_example_queries "songs from maroon 5";
description "Top tracks from an artist";
name "LastFM Artist Tracks";
icon_url "/i/www.last.fm.ico";
source "Last.fm";
code_url "https://github.com/duckduckgo/zeroclickinfo-spice/blob/master/lib/DDG/Spice/Lastfm/ArtistTracks.pm";
topics "entertainment", "music";
category "entertainment";
attribution github => ['https://github.com/jagtalon','Jag Talon'],
           twitter => ['http://twitter.com/juantalon','Jag Talon'];

spice to => 'http://ws.audioscrobbler.com/2.0/?limit=5&format=json&method=artist.gettoptracks&artist=$1&autocorrect=1&api_key={{ENV{DDG_SPICE_LASTFM_APIKEY}}}&callback={{callback}}';

#Queries like "songs by ben folds" and "ben folds songs"
my $synonyms = "songs?|tracks?|music";
triggers query_lc => qr/^(?:(?:all|the)\s+)?(?:$synonyms)\s+(?:(?:by|from|of)\s+)?([^\s]+(?:\s+[^\s]+)*)$
                        |
                        ^([^\s]+(?:\s+[^\s]+)*)\s+(?:$synonyms)$/x;


handle query_lc => sub {
    return $1 if $1;
    return $2 if $2;
    return;
};
1;

__END__
=pod

=head1 NAME

DDG::Spice::Lastfm::ArtistTracks - Get the tracks of a musician.

=head1 VERSION

version 0.265

=head1 AUTHORS

=over 4

=item *

Gabriel Weinberg <yegg@duckduckgo.com>

=item *

Torsten Raudssus <getty@duckduckgo.com>

=back

=head1 COPYRIGHT AND LICENSE

This software is copyright (c) 2011 by DuckDuckGo, Inc. L<http://duckduckgo.com/>.

This is free software; you can redistribute it and/or modify it under
the same terms as the Perl 5 programming language system itself.

=cut

