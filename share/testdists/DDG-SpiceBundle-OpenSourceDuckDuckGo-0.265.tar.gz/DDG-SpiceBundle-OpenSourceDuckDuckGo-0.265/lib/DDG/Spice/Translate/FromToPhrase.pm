package DDG::Spice::Translate::FromToPhrase;
{
  $DDG::Spice::Translate::FromToPhrase::VERSION = '0.265';
}

use DDG::Spice;
use Moo;

with('DDG::SpiceRole::Translate');

attribution github  => ['https://github.com/ghedo', 'ghedo'      ],
            web     => ['http://ghedini.me', 'Alessandro Ghedini'];

my $langs = 'arabic|ar|chinese|zh|czech|cz|english|en|french|fr|greek|gr|italian|it|japanese|ja|korean|ko|polish|pl|portuguese|pt|romanian|ro|spanish|es|turkish|tr';

spice to   => 'http://mymemory.translated.net/api/get?q=$3&langpair=$1|$2&de=office@duckduckgo.com';
spice from => '(.+)\/(.+)\/(.+)';
spice wrap_jsonp_callback => 1;

triggers start => "translate";

handle query_lc => sub {
    my $query = $_;

    $query =~ s/\s+/ /; #merge multiple spaces

    if($query =~ /^translate (.+) from ($langs)(?: to ($langs))?$/) {
        my ($phrase, $from, $to) = ($1, $2, $3);

        $from = shorten_lang($from);
        $to = (defined $to) ? shorten_lang($to) : substr($lang->locale, 0, 2);

        my $dict = $from.$to;

        # Only use mymemory for multi-word translation
        # or non-english translations
        return unless ($phrase =~ /\w+\s+\w+/ or $dict !~ /en/);

        return ($from, $to, $phrase);
    }

    return;
};

1;
__END__
=pod

=head1 NAME

DDG::Spice::Translate::FromToPhrase

=head1 VERSION

version 0.265

=head1 AUTHORS

=over 4

=item *

Gabriel Weinberg <yegg@duckduckgo.com>

=item *

Torsten Raudssus <getty@duckduckgo.com>

=back

=head1 COPYRIGHT AND LICENSE

This software is copyright (c) 2011 by DuckDuckGo, Inc. L<http://duckduckgo.com/>.

This is free software; you can redistribute it and/or modify it under
the same terms as the Perl 5 programming language system itself.

=cut

