package DDG::Spice::RandWord;
{
  $DDG::Spice::RandWord::VERSION = '0.265';
}

use DDG::Spice;

name "Random Word";
description "Generates a random word";
source "WordNik";
primary_example_queries "random word", "random word 5-10";
category "random";
topics "words_and_games", "everyday";
code_url "https://github.com/duckduckgo/zeroclickinfo-spice/blob/master/lib/DDG/Spice/RandWord.pm";
icon_url "/i/wordnik.com.ico";
attribution web => ['http://dylansserver.com','Dylan Lloyd'],
            email => ['dylan@dylansserver.com','Dylan Lloyd'];

spice from => '(?:([0-9]+)\-([0-9]+)|)';
spice to => 'http://api.wordnik.com/v4/words.json/randomWord?minLength=$1&maxLength=$2&api_key={{ENV{DDG_SPICE_RANDWORD_APIKEY}}}&callback={{callback}}';
spice proxy_cache_valid => "418 1d";

triggers any => "random word";

handle remainder => sub {
    if ($_ =~ /^([0-9]+\-[0-9]+)$/) {
    	 return $1;
    } else {
        return '0-100';
    }
    return;
};

1;

__END__
=pod

=head1 NAME

DDG::Spice::RandWord

=head1 VERSION

version 0.265

=head1 AUTHORS

=over 4

=item *

Gabriel Weinberg <yegg@duckduckgo.com>

=item *

Torsten Raudssus <getty@duckduckgo.com>

=back

=head1 COPYRIGHT AND LICENSE

This software is copyright (c) 2011 by DuckDuckGo, Inc. L<http://duckduckgo.com/>.

This is free software; you can redistribute it and/or modify it under
the same terms as the Perl 5 programming language system itself.

=cut

