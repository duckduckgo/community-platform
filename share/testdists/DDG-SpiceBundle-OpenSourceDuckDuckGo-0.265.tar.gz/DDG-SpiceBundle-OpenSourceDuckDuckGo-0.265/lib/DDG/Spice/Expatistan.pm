package DDG::Spice::Expatistan;
{
  $DDG::Spice::Expatistan::VERSION = '0.265';
}

use DDG::Spice;

primary_example_queries "cost of living in Philadelphia";
description "See and compare costs of living via Expatistan";
name "Expatisan";
icon_url "/i/www.expatistan.com.ico";
source "Expatisan";
code_url "https://github.com/duckduckgo/zeroclickinfo-spice/blob/master/lib/DDG/Spice/Expatistan.pm";
topics "economy_and_finance";
category "facts";
attribution github => ['https://github.com/hunterlang','Hunter Lang'];

triggers any => "cost of living";

spice to => 'http://www.expatistan.com/api/spice?q=$1&api_key={{ENV{DDG_SPICE_EXPATISTAN_APIKEY}}}';

handle query_lc => sub {
    return $_ if $_;
    return;
};

1;

__END__
=pod

=head1 NAME

DDG::Spice::Expatistan

=head1 VERSION

version 0.265

=head1 AUTHORS

=over 4

=item *

Gabriel Weinberg <yegg@duckduckgo.com>

=item *

Torsten Raudssus <getty@duckduckgo.com>

=back

=head1 COPYRIGHT AND LICENSE

This software is copyright (c) 2011 by DuckDuckGo, Inc. L<http://duckduckgo.com/>.

This is free software; you can redistribute it and/or modify it under
the same terms as the Perl 5 programming language system itself.

=cut

