package DDG::Spice::Tumblr;
{
  $DDG::Spice::Tumblr::VERSION = '0.265';
}

use DDG::Spice;

spice to => 'http://api.tumblr.com/v2/tagged?tag=$1&feature_type=popular&api_key={{ENV{DDG_SPICE_TUMBLR_APIKEY}}}&callback={{callback}}';

primary_example_queries "tumblr flowers";
description "Tumblr pictures";
name "Tumblr";
code_url "https://github.com/duckduckgo/zeroclickinfo-spice/blob/master/lib/DDG/Spice/Tumblr.pm";
topics "everyday", "social";
category "entertainment";
attribution github => ['https://github.com/nilnilnil','Caine Tighe'],
            twitter => ['http://twitter.com/__nil','__nil'];

triggers any => "tumblr";

handle remainder => sub {
    return $_ if $_;
};

'im a little teapot';

__END__
=pod

=head1 NAME

DDG::Spice::Tumblr

=head1 VERSION

version 0.265

=head1 AUTHORS

=over 4

=item *

Gabriel Weinberg <yegg@duckduckgo.com>

=item *

Torsten Raudssus <getty@duckduckgo.com>

=back

=head1 COPYRIGHT AND LICENSE

This software is copyright (c) 2011 by DuckDuckGo, Inc. L<http://duckduckgo.com/>.

This is free software; you can redistribute it and/or modify it under
the same terms as the Perl 5 programming language system itself.

=cut

