package DDG::Spice::DetectLang;
{
  $DDG::Spice::DetectLang::VERSION = '0.265';
}

use utf8;
use DDG::Spice;

primary_example_queries "detect language こんにちは";
secondary_example_queries "what language is como estas";
description "Detects the language";
name "Detect Language";
icon_url "/i/detectlanguage.com.ico";
source "Detect Language";
code_url "https://github.com/duckduckgo/zeroclickinfo-spice/blob/master/lib/DDG/Spice/DetectLang.pm";
topics "everyday", "words_and_games";
category "language";
attribution github  => ['https://github.com/ghedo', 'ghedo'      ],
            web     => ['http://ghedini.me', 'Alessandro Ghedini'];

spice to   => 'http://ws.detectlanguage.com/0.2/detect?q=$1&key={{ENV{DDG_SPICE_DETECTLANGUAGE_APIKEY}}}';
spice wrap_jsonp_callback => 1;

triggers startend => 'detect language', 'identify language', 'what language', 'what language is',
		     'determine language', 'check language';

handle remainder => sub {
	my ($str) = @_;

	return $str if $str;
	return
};

1;

__END__
=pod

=head1 NAME

DDG::Spice::DetectLang

=head1 VERSION

version 0.265

=head1 AUTHORS

=over 4

=item *

Gabriel Weinberg <yegg@duckduckgo.com>

=item *

Torsten Raudssus <getty@duckduckgo.com>

=back

=head1 COPYRIGHT AND LICENSE

This software is copyright (c) 2011 by DuckDuckGo, Inc. L<http://duckduckgo.com/>.

This is free software; you can redistribute it and/or modify it under
the same terms as the Perl 5 programming language system itself.

=cut

