package DDG::Spice::News;
{
  $DDG::Spice::News::VERSION = '0.265';
}
# ABSTRACT: Show current news from different sources.

use DDG::Spice;

primary_example_queries "duckduckgo news", "obama news", "government shutdown news";
description "Shows the current news about a topic.";
name "News";
code_url "https://github.com/duckduckgo/zeroclickinfo-spice/blob/master/lib/DDG/Spice/News.pm";
topics "everyday";
category "time_sensitive";
attribution github => ["https://github.com/duckduckgo/", "DuckDuckGo"],
            twitter => ["https://twitter.com/duckduckgo", "duckduckgo"];

triggers startend => "news";
spice to => 'https://duckduckgo.com/news.js?q=$1&cb={{callback}}';

handle query_lc => sub {
    return $_ if $_;
    return;
};

1;

__END__
=pod

=head1 NAME

DDG::Spice::News - Show current news from different sources.

=head1 VERSION

version 0.265

=head1 AUTHORS

=over 4

=item *

Gabriel Weinberg <yegg@duckduckgo.com>

=item *

Torsten Raudssus <getty@duckduckgo.com>

=back

=head1 COPYRIGHT AND LICENSE

This software is copyright (c) 2011 by DuckDuckGo, Inc. L<http://duckduckgo.com/>.

This is free software; you can redistribute it and/or modify it under
the same terms as the Perl 5 programming language system itself.

=cut

