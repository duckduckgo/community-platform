package DDG::Spice::RedditSubSearch;
{
  $DDG::Spice::RedditSubSearch::VERSION = '0.265';
}

use DDG::Spice;

name "SubReddit Search";
description "search for subreddits";
source "Reddit";
primary_example_queries "subreddit pizza", "/r/games";
secondary_example_queries "r/accounting";
category "forums";
topics "social";
code_url "https://github.com/duckduckgo/zeroclickinfo-spice/blob/master/lib/DDG/Spice/RedditSubSearch.pm";
icon_url "/i/www.reddit.com.ico";
attribution twitter => ["https://twitter.com/mithrandiragain","mithrandiragain"],
            github => ["https://github.com/MithrandirAgain", "Gary Herreman"],
            web => ['http://atomitware.tk/mith','MithrandirAgain'];

triggers query_lc => qr#^(?:subreddit|/?r/)\s*(\w+)$|^(\w+)\s+subreddit$#i;
spice to => 'http://www.reddit.com/r/$1/about.json?jsonp=ddg_spice_reddit';

handle matches => sub {
	if($1) {
		return $1;
	} elsif($2) {
		return $2;
	}
    return;
};

1;

__END__
=pod

=head1 NAME

DDG::Spice::RedditSubSearch

=head1 VERSION

version 0.265

=head1 AUTHORS

=over 4

=item *

Gabriel Weinberg <yegg@duckduckgo.com>

=item *

Torsten Raudssus <getty@duckduckgo.com>

=back

=head1 COPYRIGHT AND LICENSE

This software is copyright (c) 2011 by DuckDuckGo, Inc. L<http://duckduckgo.com/>.

This is free software; you can redistribute it and/or modify it under
the same terms as the Perl 5 programming language system itself.

=cut

