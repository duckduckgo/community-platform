package DDG::Spice::Hayoo;
{
  $DDG::Spice::Hayoo::VERSION = '0.265';
}

use DDG::Spice;

primary_example_queries "hayoo Prelude.map";
description "Search Haskell APIs";
name "Hayoo";
code_url "https://github.com/duckduckgo/zeroclickinfo-spice/blob/master/lib/DDG/Spice/Hayoo.pm";
icon_url "/i/hackage.haskell.org.ico";
topics "programming", "sysadmin";
category "programming";
attribution github => ['https://github.com/headprogrammingczar','headprogrammingczar'];

triggers start => "hayoo", "haskell api";

spice to => 'http://holumbus.fh-wedel.de/hayoo/hayoo.json?query=$1';
spice wrap_jsonp_callback => 1;

spice proxy_cache_valid => "200 1d";

handle remainder => sub {
    return $_ if $_;
    return;
};

1;
__END__
=pod

=head1 NAME

DDG::Spice::Hayoo

=head1 VERSION

version 0.265

=head1 AUTHORS

=over 4

=item *

Gabriel Weinberg <yegg@duckduckgo.com>

=item *

Torsten Raudssus <getty@duckduckgo.com>

=back

=head1 COPYRIGHT AND LICENSE

This software is copyright (c) 2011 by DuckDuckGo, Inc. L<http://duckduckgo.com/>.

This is free software; you can redistribute it and/or modify it under
the same terms as the Perl 5 programming language system itself.

=cut

