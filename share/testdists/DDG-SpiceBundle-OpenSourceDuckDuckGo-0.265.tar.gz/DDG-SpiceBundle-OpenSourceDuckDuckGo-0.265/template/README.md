Instant Answer templates to be used in conjugation with DuckPAN

